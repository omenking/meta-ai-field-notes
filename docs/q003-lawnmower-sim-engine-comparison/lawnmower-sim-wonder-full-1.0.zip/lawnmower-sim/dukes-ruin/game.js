// ================= DUKE'S RUIN — ride-on lawnmower simulator =================
// First person: palms on the wheel, beer (Q) in the left hand, cigar (E) in the right.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const $=id=>document.getElementById(id);
const REDUCED=matchMedia('(prefers-reduced-motion: reduce)').matches;
let seed=1337; const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646};
const rr=(a,b)=>a+rnd()*(b-a), clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), lerp=(a,b,t)=>a+(b-a)*t;
const smooth=t=>t*t*(3-2*t);

// ---------- renderer / scene ----------
const renderer=new THREE.WebGLRenderer({canvas:$('c'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.08;
renderer.outputColorSpace=THREE.SRGBColorSpace;
const scene=new THREE.Scene();
scene.fog=new THREE.Fog(0xd8c9a0,55,175);
const pmrem=new THREE.PMREMGenerator(renderer);
scene.environment=pmrem.fromScene(new RoomEnvironment(),.04).texture;
const camera=new THREE.PerspectiveCamera(innerWidth<innerHeight?88:71,innerWidth/innerHeight,.05,420);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.fov=innerWidth<innerHeight?88:71;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});

// sky dome (gradient shader) + sun disc glow via sprite
{
  const skyMat=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,
    uniforms:{},
    vertexShader:`varying vec3 vP; void main(){vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`varying vec3 vP; void main(){float h=normalize(vP).y;
      vec3 top=vec3(.30,.52,.78), mid=vec3(.72,.80,.88), hor=vec3(1.,.82,.55);
      vec3 c=h>.25?mix(mid,top,smoothstep(.25,.9,h)):mix(hor,mid,smoothstep(-.05,.25,h));
      gl_FragColor=vec4(c,1.);}`});
  scene.add(new THREE.Mesh(new THREE.SphereGeometry(390,24,16),skyMat));
}
const hemi=new THREE.HemisphereLight(0xbfd6ff,0x5a6b34,.85); scene.add(hemi);
const sun=new THREE.DirectionalLight(0xffd9a0,2.6);
sun.position.set(42,48,26); sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);
Object.assign(sun.shadow.camera,{left:-62,right:62,top:62,bottom:-62,near:5,far:170});
sun.shadow.bias=-0.0006; sun.shadow.normalBias=.03; scene.add(sun,sun.target);
const fill=new THREE.DirectionalLight(0xaac4ff,.35); fill.position.set(-30,22,-30); scene.add(fill);

// ---------- code-drawn textures ----------
function ctex(w,h,draw,rep){
  const c=document.createElement('canvas'); c.width=w; c.height=h;
  draw(c.getContext('2d'),w,h);
  const t=new THREE.CanvasTexture(c); t.colorSpace=THREE.SRGBColorSpace; t.anisotropy=4;
  if(rep){t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(rep[0],rep[1])}
  return t;
}
function speckle(x,w,h,n,cols,s0=1,s1=3){for(let i=0;i<n;i++){x.fillStyle=cols[(rnd()*cols.length)|0];x.globalAlpha=rr(.15,.7);const s=rr(s0,s1);x.fillRect(rnd()*w,rnd()*h,s,s)}x.globalAlpha=1}
const stoneTex=ctex(512,512,(x,w,h)=>{
  x.fillStyle='#b3a482';x.fillRect(0,0,w,h);
  const bh=42,bw=104;
  for(let y=0;y<h/bh;y++)for(let xx=-1;xx<w/bw+1;xx++){
    const ox=(y%2)*bw/2, v=rr(-14,14);
    x.fillStyle=`rgb(${176+v|0},${163+v|0},${126+v|0})`; x.fillRect(xx*bw+ox+2,y*bh+2,bw-4,bh-4);
    x.fillStyle='rgba(255,255,255,.13)'; x.fillRect(xx*bw+ox+2,y*bh+2,bw-4,3);
    x.fillStyle='rgba(60,50,30,.18)'; x.fillRect(xx*bw+ox+2,y*bh+bh-6,bw-4,4);
  }
  speckle(x,w,h,2600,['#8f8062','#c9bb96','#6f6248','#d8ccab'],1,3);
  for(let i=0;i<26;i++){ // damp streaks
    x.fillStyle='rgba(52,54,38,.16)'; const sx=rnd()*w; x.fillRect(sx,rnd()*h*.5,rr(3,11),rr(40,190));
  }
  for(let i=0;i<10;i++){ // cracks
    x.strokeStyle='rgba(45,40,28,.55)'; x.lineWidth=1.4; x.beginPath();
    let px=rnd()*w,py=rnd()*h; x.moveTo(px,py);
    for(let s=0;s<7;s++){px+=rr(-16,16);py+=rr(8,26);x.lineTo(px,py)} x.stroke();
  }
},[3,2]);
const roofTex=ctex(512,512,(x,w,h)=>{
  x.fillStyle='#454d59';x.fillRect(0,0,w,h); const th=30,tw=44;
  for(let y=0;y<h/th;y++)for(let xx=0;xx<w/tw+1;xx++){
    const ox=(y%2)*tw/2,v=rr(-11,13);
    x.fillStyle=`rgb(${70+v|0},${78+v|0},${92+v|0})`;x.fillRect(xx*tw+ox+1,y*th+1,tw-2,th-2);
    x.fillStyle='rgba(0,0,0,.28)';x.fillRect(xx*tw+ox+1,y*th+th-4,tw-2,3);
    if(rnd()<.06){x.fillStyle='#24271f';x.fillRect(xx*tw+ox+1,y*th+1,tw-2,th-2)} // missing slate
  }
  speckle(x,w,h,700,['#5d6b3c','#75855c'],2,7); // moss
},[4,3]);
const gravelTex=ctex(256,256,(x,w,h)=>{x.fillStyle='#a79a80';x.fillRect(0,0,w,h);speckle(x,w,h,5200,['#8d8069','#c2b49a','#6f6450','#d5c9ad','#7d7466'],1,3);speckle(x,w,h,180,['#5f7038'],2,5)},[10,10]);
const woodTex=ctex(256,256,(x,w,h)=>{x.fillStyle='#6b4a26';x.fillRect(0,0,w,h);for(let i=0;i<70;i++){x.strokeStyle=`rgba(${40+rnd()*50|0},${26+rnd()*30|0},10,.5)`;x.lineWidth=rr(1,3);x.beginPath();x.moveTo(0,rnd()*h);x.bezierCurveTo(w*.3,rnd()*h,w*.6,rnd()*h,w,rnd()*h);x.stroke()}},[1,1]);
const leafTex=ctex(256,256,(x,w,h)=>{x.fillStyle='#446322';x.fillRect(0,0,w,h);for(let i=0;i<2800;i++){x.save();x.translate(rnd()*w,rnd()*h);x.rotate(rnd()*6.3);x.fillStyle=['#557c2b','#3c5c1d','#6b973a','#2f4f16','#7fae45'][(rnd()*5)|0];x.beginPath();x.ellipse(0,0,rr(2,5),rr(1.2,3),0,0,6.3);x.fill();x.restore()}},[2,2]);
const soilTex=ctex(256,256,(x,w,h)=>{x.fillStyle='#4a3722';x.fillRect(0,0,w,h);speckle(x,w,h,3000,['#5d4630','#38281a','#6c563d','#2e2013'],1,4)},[3,3]);
const tyreTex=ctex(128,128,(x,w,h)=>{x.fillStyle='#191919';x.fillRect(0,0,w,h);x.fillStyle='#2c2c2c';for(let i=0;i<8;i++){x.save();x.translate(i*16+8,h/2);x.rotate(.5);x.fillRect(-5,-h/2,10,h);x.restore()}},[6,1]);
const softTex=ctex(64,64,(x,w,h)=>{const g=x.createRadialGradient(32,32,2,32,32,31);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.5,'rgba(255,255,255,.45)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,w,h)});
const beerLabel=ctex(256,160,(x,w,h)=>{
  x.fillStyle='#f3e7c8';x.fillRect(0,0,w,h);x.strokeStyle='#8a1f1f';x.lineWidth=7;x.strokeRect(7,7,w-14,h-14);
  x.fillStyle='#8a1f1f';x.font='900 27px Georgia';x.textAlign='center';x.fillText("DUKE'S RUIN",w/2,48);
  x.font='700 15px Georgia';x.fillStyle='#4d3a10';x.fillText('★ ESTATE IPA ★',w/2,74);
  x.font='italic 13px Georgia';x.fillText('brewed in the collapsed orangery',w/2,99);
  x.fillStyle='#8a1f1f';x.font='900 21px Georgia';x.fillText('6.6% · ICE COLD',w/2,131);
});
function windowTex(kind){return ctex(128,192,(x,w,h)=>{
  if(kind==='board'){x.fillStyle='#241c12';x.fillRect(0,0,w,h);x.fillStyle='#7a5a30';for(let i=0;i<5;i++){x.save();x.translate(w/2,20+i*38);x.rotate(rr(-.06,.06));x.fillRect(-w/2+3,-14,w-6,28);x.restore()}return}
  const g=x.createLinearGradient(0,0,w,h);
  if(kind==='lit'){g.addColorStop(0,'#ffca6a');g.addColorStop(1,'#c07c22')}
  else{g.addColorStop(0,'#5f768c');g.addColorStop(.5,'#2c3a48');g.addColorStop(1,'#171e28')}
  x.fillStyle=g;x.fillRect(0,0,w,h);
  x.fillStyle='rgba(255,255,255,.20)';x.beginPath();x.moveTo(8,h);x.lineTo(w*.55,0);x.lineTo(w*.8,0);x.lineTo(w*.3,h);x.fill();
  if(kind==='crack'){x.strokeStyle='rgba(230,240,250,.8)';x.lineWidth=1.2;const cx=w*.6,cy=h*.42;
    for(let i=0;i<9;i++){const a=i/9*6.28;x.beginPath();x.moveTo(cx,cy);x.lineTo(cx+Math.cos(a)*rr(22,58),cy+Math.sin(a)*rr(22,58));x.stroke()}
    x.beginPath();x.arc(cx,cy,13,0,6.3);x.stroke();x.fillStyle='#0b0e13';x.fillRect(w*.55,h*.62,42,52)}
  if(kind==='ivy'){for(let i=0;i<130;i++){x.fillStyle=['#3c5c1d','#557c2b','#2f4f16'][(rnd()*3)|0];x.beginPath();x.ellipse(rnd()*w,rnd()*h,rr(4,9),rr(3,6),rnd()*3,0,6.3);x.fill()}}
})}
const winTexes={plain:windowTex('plain'),crack:windowTex('crack'),board:windowTex('board'),lit:windowTex('lit'),ivy:windowTex('ivy')};

// ---------- shared materials ----------
const M={
  stone:new THREE.MeshStandardMaterial({map:stoneTex,roughness:.92}),
  stoneDark:new THREE.MeshStandardMaterial({color:0x8d8169,roughness:.95}),
  roof:new THREE.MeshStandardMaterial({map:roofTex,roughness:.85}),
  trim:new THREE.MeshStandardMaterial({color:0xd9d2bd,roughness:.8}),
  wood:new THREE.MeshStandardMaterial({map:woodTex,roughness:.85}),
  woodDark:new THREE.MeshStandardMaterial({color:0x3d2a16,roughness:.9}),
  leaf:new THREE.MeshStandardMaterial({map:leafTex,roughness:.95,flatShading:true}),
  leafDark:new THREE.MeshStandardMaterial({map:leafTex,color:0x77875e,roughness:.95,flatShading:true}),
  hedge:new THREE.MeshStandardMaterial({map:leafTex,color:0x86a05e,roughness:1,flatShading:true}),
  bark:new THREE.MeshStandardMaterial({color:0x57402a,roughness:1}),
  iron:new THREE.MeshStandardMaterial({color:0x23272a,roughness:.55,metalness:.75}),
  rust:new THREE.MeshStandardMaterial({color:0x7a4a2a,roughness:.8,metalness:.35}),
  brass:new THREE.MeshStandardMaterial({color:0xc9a24a,roughness:.3,metalness:1}),
  chrome:new THREE.MeshStandardMaterial({color:0xd7dde2,roughness:.18,metalness:1}),
  marble:new THREE.MeshStandardMaterial({color:0xcfc9bc,roughness:.6}),
  mossStone:new THREE.MeshStandardMaterial({color:0x9a967e,roughness:.95}),
  gravel:new THREE.MeshStandardMaterial({map:gravelTex,roughness:1}),
  soil:new THREE.MeshStandardMaterial({map:soilTex,roughness:1}),
  redPaint:new THREE.MeshStandardMaterial({color:0xb02018,roughness:.34,metalness:.22,envMapIntensity:.55}),
  blackPlastic:new THREE.MeshStandardMaterial({color:0x16181a,roughness:.6}),
  tyre:new THREE.MeshStandardMaterial({map:tyreTex,roughness:.95}),
  skin:new THREE.MeshStandardMaterial({color:0xb77a4e,roughness:.75}),
  jeans:new THREE.MeshStandardMaterial({color:0x2d4a76,roughness:.9}),
  shirt:new THREE.MeshStandardMaterial({color:0x8a3324,roughness:.85}),
};
const box=(w,h,d,m)=>new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);
const rbox=(w,h,d,r,m)=>new THREE.Mesh(new RoundedBoxGeometry(w,h,d,3,r),m);
const cyl=(rt,rb,h,m,seg=14)=>new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,seg),m);
function sph(r,m,w=14,h=10){
  const g=new THREE.SphereGeometry(r,w,h);
  if(m===M.leaf||m===M.leafDark||m===M.hedge){ // break the watermelon: lumpy foliage
    const p=g.attributes.position, v=new THREE.Vector3(), ph1=rr(0,20), ph2=rr(0,20);
    for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i).normalize();
      const n=Math.sin((v.x*12.9+v.y*78.2+v.z*37.7)*6.1+ph1)*.6+Math.sin((v.x*5.3-v.y*9.1+v.z*7.7)*11.3+ph2)*.4;
      const s=r*(1+n*.14); p.setXYZ(i,v.x*s,v.y*s,v.z*s);}
    g.computeVertexNormals();
  }
  return new THREE.Mesh(g,m);
}
function put(parent,obj,x,y,z,ry=0,shadow=true){obj.position.set(x,y,z);obj.rotation.y=ry;if(shadow){obj.castShadow=true;obj.receiveShadow=true}parent.add(obj);return obj}

// ---------- estate ground + live mow-paint ----------
const LAWN={x0:-40,x1:40,z0:-34,z1:34};
const groundCanvas=document.createElement('canvas'); groundCanvas.width=groundCanvas.height=1024;
const gx2=groundCanvas.getContext('2d');
function paintBaseGround(){
  gx2.fillStyle='#4d6126'; gx2.fillRect(0,0,1024,1024);
  for(let i=0;i<900;i++){ // scruffy overgrown mottling
    gx2.fillStyle=['#42551f','#5a702e','#66793a','#3c4e1d','#715f33','#4f5b28'][(rnd()*6)|0];
    gx2.globalAlpha=rr(.12,.4); gx2.beginPath(); gx2.ellipse(rnd()*1024,rnd()*1024,rr(8,52),rr(6,30),rnd()*3,0,6.3); gx2.fill();
  }
  gx2.globalAlpha=1;
  for(let i=0;i<26000;i++){gx2.fillStyle=['#5d7531','#3a4d1c','#7a8a47','#6b5c2e'][(rnd()*4)|0];gx2.globalAlpha=rr(.2,.8);gx2.fillRect(rnd()*1024,rnd()*1024,rr(1,3),rr(2,5))}
  gx2.globalAlpha=1;
  for(let i=0;i<40;i++){ // bare dirt scuffs
    gx2.fillStyle='rgba(104,86,52,.35)'; gx2.beginPath(); gx2.ellipse(rnd()*1024,rnd()*1024,rr(6,24),rr(4,13),rnd()*3,0,6.3); gx2.fill();
  }
}
paintBaseGround();
const groundTex=new THREE.CanvasTexture(groundCanvas); groundTex.colorSpace=THREE.SRGBColorSpace; groundTex.anisotropy=8;
const W2CX=x=>(x-LAWN.x0)/(LAWN.x1-LAWN.x0)*1024, W2CY=z=>(z-LAWN.z0)/(LAWN.z1-LAWN.z0)*1024;
function paintMow(wx,wz,yaw,w=1.5,l=1.7){
  // stripe brightness flips with travel direction vs sun => back-and-forth passes stripe like Wimbledon
  const sunAz=Math.atan2(42,26), t=.5+.5*Math.cos(yaw-sunAz);
  const c1=[98,152,48],c2=[124,176,64];
  gx2.save(); gx2.translate(W2CX(wx),W2CY(wz)); gx2.rotate(-yaw+Math.PI);
  gx2.fillStyle=`rgb(${c1[0]+(c2[0]-c1[0])*t|0},${c1[1]+(c2[1]-c1[1])*t|0},${c1[2]+(c2[2]-c1[2])*t|0})`;
  const cw=w/(LAWN.x1-LAWN.x0)*1024, cl=l/(LAWN.z1-LAWN.z0)*1024;
  gx2.fillRect(-cw/2,-cl/2,cw,cl);
  for(let i=0;i<14;i++){gx2.fillStyle=Math.random()<.5?'rgba(70,120,34,.25)':'rgba(160,205,90,.22)';gx2.fillRect(-cw/2+Math.random()*cw,-cl/2+Math.random()*cl,2,3)}
  gx2.fillStyle='rgba(90,130,40,.35)'; gx2.fillRect(-cw/2,-cl/2,3,cl); gx2.fillRect(cw/2-3,-cl/2,3,cl); // wheel lines
  gx2.restore(); groundTex.needsUpdate=true;
}
{ // base ground (far meadow) + lawn plane
  const far=new THREE.Mesh(new THREE.PlaneGeometry(500,500),new THREE.MeshStandardMaterial({color:0x55683a,roughness:1}));
  far.rotation.x=-Math.PI/2; far.position.y=-.05; far.receiveShadow=true; scene.add(far);
  const detailTex=ctex(256,256,(x,w,h)=>{x.fillStyle='#808080';x.fillRect(0,0,w,h);for(let i=0;i<5200;i++){x.strokeStyle=rnd()<.5?'#a8a8a8':'#585858';x.lineWidth=1;const px=rnd()*w,py=rnd()*h;x.beginPath();x.moveTo(px,py);x.lineTo(px+rr(-3,3),py-rr(3,8));x.stroke()}},[52,44]);
  const lawn=new THREE.Mesh(new THREE.PlaneGeometry(LAWN.x1-LAWN.x0,LAWN.z1-LAWN.z0),new THREE.MeshStandardMaterial({map:groundTex,bumpMap:detailTex,bumpScale:.7,roughness:1}));
  lawn.rotation.x=-Math.PI/2; lawn.position.set((LAWN.x0+LAWN.x1)/2,0,(LAWN.z0+LAWN.z1)/2); lawn.receiveShadow=true; scene.add(lawn);
  // distant tree line silhouettes
  for(let i=0;i<60;i++){
    const a=i/60*Math.PI*2, d=rr(95,165), h=rr(9,19);
    const t=sph(h*.55,M.leafDark,8,6); t.position.set(Math.cos(a)*d,h*.62,Math.sin(a)*d+10); t.scale.y=1.25; scene.add(t);
    const tr=cyl(.3,.5,h*.7,M.bark,6); tr.position.set(Math.cos(a)*d,h*.3,Math.sin(a)*d+10); scene.add(tr);
  }
  for(let i=0;i<9;i++){ // rolling far hills
    const hill=sph(rr(38,70),new THREE.MeshStandardMaterial({color:0x5d7440,roughness:1}),12,8);
    const a=rr(0,6.3); hill.position.set(Math.cos(a)*rr(180,240),-rr(24,38),Math.sin(a)*rr(180,240)); hill.scale.y=.42; scene.add(hill);
  }
}
// where tall grass may grow (not drive / house / fountain / pond / beds)
const BEDS=[[-20,-9,-13,3],[13,-9,20,3],[-20,13,-13,24],[13,13,20,24]];
function inRect(x,z,r){return x>r[0]&&x<r[2]&&z>r[1]&&z<r[3]}
function isGrass(x,z){
  if(x<LAWN.x0+1||x>LAWN.x1-1||z<LAWN.z0+1||z>LAWN.z1-1) return false;
  if(z<-17.5&&x>-26&&x<26) return false;                    // manor terrace
  if(Math.abs(x)<3.1&&z>-16) return false;                  // gravel drive
  if(Math.hypot(x,z+6)<9.4) return false;                   // fountain loop
  if(Math.hypot((x+29)/7,(z-22)/5)<1.05) return false;      // pond SW
  if(x>24&&x<35&&z>-16&&z<-4) return false;                 // greenhouse
  for(const b of BEDS) if(inRect(x,z,b)) return false;      // formal beds
  if(Math.abs(z-6)<1.1&&Math.abs(x)>3.2&&Math.abs(x)<21) return false; // cross path
  return true;
}
// colliders
const COL_C=[],COL_B=[];
const colC=(x,z,r)=>COL_C.push({x,z,r}), colB=(x0,z0,x1,z1)=>COL_B.push({x0,z0,x1,z1});
colB(-26,-33,26,-18.2);            // manor
colC(0,-6,3.9);                    // fountain
for(const b of BEDS) colB(b[0],b[1],b[2],b[3]);
colB(24,-16,35,-4);                // greenhouse
colC(-29,22,7.5);                  // pond rim

// ---------- THE MANOR: a dilapidated ducal pile ----------
const estate=new THREE.Group(); scene.add(estate);
function windowUnit(kind,w=1.15,h=2.0){
  const g=new THREE.Group();
  const frame=box(w+.22,h+.22,.14,M.trim); frame.castShadow=true; g.add(frame);
  const glass=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:winTexes[kind],roughness:kind==='lit'?.4:.15,metalness:kind==='lit'?0:.4,emissive:kind==='lit'?0xff9a30:0x000000,emissiveIntensity:kind==='lit'?.9:0}));
  glass.position.z=.085; g.add(glass);
  const mullV=box(.06,h,.03,M.trim); mullV.position.z=.1; g.add(mullV);
  const mullH=box(w,.06,.03,M.trim); mullH.position.z=.1; g.add(mullH);
  const sill=box(w+.4,.14,.3,M.stoneDark); sill.position.set(0,-h/2-.12,.05); sill.castShadow=true; g.add(sill);
  if(rnd()<.45){ // peeling shutter, one hanging by a hinge
    const sh=box(w*.52,h*.92,.05,new THREE.MeshStandardMaterial({color:0x44543a,roughness:.9}));
    sh.position.set(-w*.82,0,.05); sh.castShadow=true; g.add(sh);
    const sh2=sh.clone(); sh2.position.set(w*.82,-.18,.05); sh2.rotation.z=rr(.12,.3); g.add(sh2);
  }
  return g;
}
function pitchedRoof(w,d,h,m){
  const shape=new THREE.Shape(); shape.moveTo(-w/2,0); shape.lineTo(w/2,0); shape.lineTo(0,h); shape.closePath();
  const geo=new THREE.ExtrudeGeometry(shape,{depth:d,bevelEnabled:false}); geo.translate(0,0,-d/2);
  const mesh=new THREE.Mesh(geo,m); mesh.castShadow=true; mesh.receiveShadow=true; return mesh;
}
function ridgeRoof(w,d,h,m){ // ridge runs east-west, slopes face the lawn
  const shape=new THREE.Shape(); shape.moveTo(-d/2,0); shape.lineTo(d/2,0); shape.lineTo(0,h); shape.closePath();
  const geo=new THREE.ExtrudeGeometry(shape,{depth:w,bevelEnabled:false});
  geo.translate(0,0,-w/2); geo.rotateY(Math.PI/2);
  const mesh=new THREE.Mesh(geo,m); mesh.castShadow=true; mesh.receiveShadow=true; return mesh;
}
function manorBlock(cx,cz,w,d,floors,roofH){
  const g=new THREE.Group(); const wallH=floors*3.1;
  const body=box(w,wallH,d,M.stone); put(g,body,0,wallH/2,0);
  const plinth=box(w+.5,1,d+.5,M.stoneDark); put(g,plinth,0,.5,0);
  const cornice=box(w+.6,.45,d+.6,M.trim); put(g,cornice,0,wallH+.1,0);
  for(let f=1;f<floors;f++){const band=box(w+.24,.22,d+.24,M.trim); put(g,band,0,f*3.1,0)}
  const roof=ridgeRoof(w+.7,d+.7,roofH,M.roof); put(g,roof,0,wallH+.3,0);
  // roof dormers
  const nD=Math.max(2,(w/5)|0);
  for(let i=0;i<nD;i++){
    const dx=-w/2+ (i+.5)*w/nD;
    const dorm=new THREE.Group();
    put(dorm,box(1.1,1.15,1,M.stone),0,.55,0);
    const dr=pitchedRoof(1.3,1.25,.6,M.roof); put(dorm,dr,0,1.12,0);
    const dw=windowUnit(rnd()<.5?'crack':'plain',.62,.8); dw.position.set(0,.55,.52); dorm.add(dw);
    dorm.position.set(dx,wallH+.45,d/2-1.15); dorm.rotation.x=-.0; g.add(dorm);
  }
  // chimneys with clay pots, one crumbled
  for(const sx of[-w*.32,w*.32]){
    const ch=new THREE.Group(); const crumb=rnd()<.4;
    put(ch,box(1.3,crumb?1.2:2.4,1.1,M.stone),0,(crumb?1.2:2.4)/2,0);
    if(!crumb) for(let p=0;p<3;p++) put(ch,cyl(.14,.18,.65,M.rust,8),-.36+p*.36,2.7,0);
    else put(ch,box(.5,.4,.5,M.stoneDark),.5,.2,.9,.7);
    ch.position.set(sx,wallH+roofH*.55,0); g.add(ch);
  }
  // windows on the south face
  const kinds=['plain','plain','crack','ivy','board','plain','crack'];
  const cols=Math.max(3,Math.round(w/3.4));
  for(let f=0;f<floors;f++)for(let cix=0;cix<cols;cix++){
    const wx=-w/2+(cix+.5)*w/cols, wy=1.7+f*3.1;
    if(f===0&&cx===0&&Math.abs(wx)<2.2) continue; // front door gap on main block
    let kind=kinds[(rnd()*kinds.length)|0];
    if(cx===0&&f===1&&cix===cols-2) kind='lit'; // one mysterious lit window
    const win=windowUnit(kind,f===0?1.25:1.05,f===0?2.3:1.85);
    win.position.set(wx,wy,d/2+.06); g.add(win);
  }
  g.position.set(cx,0,cz); estate.add(g); return g;
}
manorBlock(0,-26,27,11,3,4.2);
manorBlock(-19.5,-25,11,9,2,3.2);
manorBlock(19.5,-25,11,9,2,3.2);
{ // portico, pediment clock, front door (one leaf ajar), cracked steps, urns
  const g=new THREE.Group(); g.position.set(0,0,-20.4); estate.add(g);
  for(let s=0;s<4;s++) put(g,box(6.4-s*.7,.22,1.1,M.stoneDark),rr(-.05,.05),.11+s*.21,2.2-s*.45,rr(-.01,.01));
  for(const px of[-2.6,-.9,.9,2.6]){
    put(g,cyl(.24,.3,4.6,M.trim,12),px,2.3+.85,.4);
    put(g,box(.66,.3,.66,M.trim),px,5.35,.4); put(g,box(.7,.35,.7,M.stoneDark),px,1.0,.4);
  }
  put(g,box(6.6,.5,1.7,M.trim),0,5.65,.4);
  const ped=pitchedRoof(6.6,1.7,1.5,M.stone); put(g,ped,0,5.9,.4);
  const clockTex=ctex(128,128,(x)=>{x.fillStyle='#e9e0c4';x.beginPath();x.arc(64,64,60,0,6.3);x.fill();x.strokeStyle='#4d3a10';x.lineWidth=5;x.stroke();
    x.fillStyle='#2b2417';for(let i=0;i<12;i++){const a=i/12*6.28;x.fillRect(62+Math.cos(a)*48,62+Math.sin(a)*48,4,4)}
    x.lineWidth=6;x.beginPath();x.moveTo(64,64);x.lineTo(64+22,64-26);x.stroke();x.beginPath();x.moveTo(64,64);x.lineTo(64-6,64+34);x.stroke();
    x.strokeStyle='rgba(60,50,30,.6)';x.lineWidth=1.5;x.beginPath();x.moveTo(20,28);x.lineTo(70,72);x.lineTo(96,110);x.stroke();});
  const clock=new THREE.Mesh(new THREE.CircleGeometry(.55,24),new THREE.MeshStandardMaterial({map:clockTex,roughness:.5}));
  clock.position.set(0,6.35,1.28); g.add(clock); // stopped at 4:20, forever
  const doorF=box(2.5,3.4,.18,M.trim); put(g,doorF,0,2.55,-.1);
  const d1=box(1.05,3.1,.09,M.woodDark); put(g,d1,-.55,2.5,0);
  const d2=box(1.05,3.1,.09,M.wood); d2.position.set(.62,2.5,.13); d2.rotation.y=-.38; d2.castShadow=true; g.add(d2);
  put(g,sph(.07,M.brass),-.12,2.5,.1); put(g,sph(.07,M.brass),.35,2.5,.2);
  const lamp=box(.24,.36,.24,M.iron); lamp.position.set(-1.8,3.6,.1); lamp.rotation.z=.35; lamp.castShadow=true; g.add(lamp);
  for(const ux of[-3.4,3.4]){ // cracked urns sprouting weeds
    const urn=new THREE.Mesh(new THREE.LatheGeometry([[.06,0],[.34,.06],[.4,.3],[.28,.58],[.4,.78],[.44,.86]].map(p=>new THREE.Vector2(p[0],p[1])),12),M.mossStone);
    put(g,urn,ux,1.0,1.2,0); put(g,box(.8,1,.8,M.stoneDark),ux,.5,1.2);
    put(g,sph(.34,M.leaf,8,6),ux,2.05,1.2);
  }
  // fallen column drum + rubble on the terrace
  const drum=cyl(.3,.3,1.1,M.trim,12); drum.rotation.z=Math.PI/2; drum.position.set(4.6,.3,2.6); drum.castShadow=true; g.add(drum);
  for(let i=0;i<9;i++) put(g,box(rr(.2,.55),rr(.15,.35),rr(.2,.5),M.stoneDark),rr(-6,6.5),.12,rr(2,4.2),rr(0,3));
}
// ivy strangling the facade
for(let i=0;i<130;i++){
  const side=rnd()<.5?-1:1, h=rr(.3,8.5), spread=Math.max(.5,4-h*.32);
  const iv=sph(rr(.28,.62),M.leaf,7,5);
  iv.position.set(side*rr(9,13.4)+rr(-spread,spread)*.4,h,-20.2+rr(-.15,.3)); iv.scale.z=.45; estate.add(iv);
}
for(let i=0;i<40;i++){const iv=sph(rr(.24,.5),M.leafDark,7,5);iv.position.set(rr(-24,24),rr(.3,3),-20.25);iv.scale.z=.4;estate.add(iv)}

// terrace + balustrade in front of manor
put(estate,box(52,.22,4.5,M.stoneDark),0,.11,-18.6);
for(let i=0;i<=44;i++){const bx=-25.5+i*1.16; if(Math.abs(bx)<3.4) continue;
  if(i%11===5){put(estate,box(.3,.5,.3,M.stoneDark),bx,.25,-16.6);continue} // missing balusters
  put(estate,cyl(.07,.1,.62,M.trim,7),bx,.45,-16.6,0,false);}
put(estate,box(52,.14,.34,M.trim),0,.82,-16.6);

// gravel drive + cross path + fountain loop
function flatPlane(w,d,m,x,z,y=.02,ry=0){const p=new THREE.Mesh(new THREE.PlaneGeometry(w,d),m);p.rotation.x=-Math.PI/2;p.rotation.z=ry;p.position.set(x,y,z);p.receiveShadow=true;estate.add(p);return p}
flatPlane(6.2,50,M.gravel,0,8);
flatPlane(42,2.2,M.gravel,0,6);
{const loop=new THREE.Mesh(new THREE.RingGeometry(3.9,9.4,40),M.gravel);loop.rotation.x=-Math.PI/2;loop.position.set(0,.025,-6);loop.receiveShadow=true;estate.add(loop);
 const loopIn=new THREE.Mesh(new THREE.CircleGeometry(3.9,32),new THREE.MeshStandardMaterial({color:0x5d7038,roughness:1}));loopIn.rotation.x=-Math.PI/2;loopIn.position.set(0,.02,-6);loopIn.receiveShadow=true;estate.add(loopIn);}
// fountain: algae soup, cherub, a pathetic trickle
const fountainWater=(()=> {
  const g=new THREE.Group(); g.position.set(0,0,-6); estate.add(g);
  put(g,cyl(3.5,3.7,.75,M.mossStone,28),0,.37,0);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(3.5,.14,10,36),M.stoneDark); rim.rotation.x=Math.PI/2; rim.position.y=.78; rim.castShadow=true; g.add(rim);
  const water=new THREE.Mesh(new THREE.CircleGeometry(3.3,28),new THREE.MeshStandardMaterial({color:0x4d6228,roughness:.15,metalness:.1}));
  water.rotation.x=-Math.PI/2; water.position.y=.66; g.add(water);
  for(let i=0;i<12;i++){const pad=new THREE.Mesh(new THREE.CircleGeometry(rr(.14,.3),10),new THREE.MeshStandardMaterial({color:0x5d7d2e,roughness:.8}));pad.rotation.x=-Math.PI/2;const a=rr(0,6.3),rd=rr(.6,2.9);pad.position.set(Math.cos(a)*rd,.68,Math.sin(a)*rd);g.add(pad)}
  put(g,cyl(.22,.4,1.5,M.mossStone,10),0,1.2,0);
  const tier=new THREE.Mesh(new THREE.LatheGeometry([[.05,0],[.9,.08],[1.0,.22],[.2,.3]].map(p=>new THREE.Vector2(p[0],p[1])),18),M.mossStone); put(g,tier,0,1.9,0);
  put(g,cyl(.1,.16,.7,M.mossStone,8),0,2.4,0);
  const cherub=new THREE.Group(); put(cherub,sph(.17,M.marble),0,.62,0); put(cherub,cyl(.13,.2,.5,M.marble,8),0,.3,0);
  const wing=box(.05,.4,.3,M.marble); wing.position.set(-.18,.45,-.1); wing.rotation.z=.6; cherub.add(wing);
  cherub.position.set(0,2.72,.06); cherub.rotation.z=.16; cherub.rotation.x=.2; g.add(cherub); // listing drunk since 1897
  const trickle=cyl(.015,.02,.75,new THREE.MeshStandardMaterial({color:0xbcd8e8,transparent:true,opacity:.65,roughness:.1}),6);
  trickle.position.set(.25,2.35,.1); trickle.rotation.z=.3; g.add(trickle);
  return water;
})();

// formal beds (gone feral), rose bushes, hedge maze of parterre
for(const b of BEDS){
  const w=b[2]-b[0],d=b[3]-b[1],cx=(b[0]+b[2])/2,cz=(b[1]+b[3])/2;
  put(estate,box(w,.18,d,M.soil),cx,.09,cz);
  put(estate,box(w+.3,.3,.28,M.stoneDark),cx,.15,b[1]-.05); put(estate,box(w+.3,.3,.28,M.stoneDark),cx,.15,b[3]+.05);
  put(estate,box(.28,.3,d+.3,M.stoneDark),b[0]-.05,.15,cz); put(estate,box(.28,.3,d+.3,M.stoneDark),b[2]+.05,.15,cz);
  for(let i=0;i<9;i++){
    const bush=sph(rr(.45,.85),M.leaf,8,6); put(estate,bush,rr(b[0]+.7,b[2]-.7),rr(.4,.65),rr(b[1]+.7,b[3]-.7));
    for(let f=0;f<7;f++){const rose=sph(.07,new THREE.MeshStandardMaterial({color:[0xc23b4e,0xe87a9a,0xe8e3d0][(rnd()*3)|0],roughness:.6}),6,5);
      const a=rr(0,6.3); rose.position.set(bush.position.x+Math.cos(a)*.55,bush.position.y+rr(0,.4),bush.position.z+Math.sin(a)*.55); estate.add(rose)}
  }
}
function hedge(x,z,w,d,h=1.15){
  const geo=new RoundedBoxGeometry(w,h,d,2,.18);
  const pos=geo.attributes.position;
  for(let i=0;i<pos.count;i++){pos.setXYZ(i,pos.getX(i)+rr(-.05,.05),pos.getY(i)+rr(-.06,.06),pos.getZ(i)+rr(-.05,.05))}
  geo.computeVertexNormals();
  const m=new THREE.Mesh(geo,M.hedge); put(estate,m,x,h/2,z);
  for(let i=0;i<Math.max(2,w*d/4);i++) put(estate,sph(rr(.22,.45),M.leaf,7,5),x+rr(-w/2,w/2),h+rr(-.05,.25),z+rr(-d/2,d/2)); // shaggy top
  colB(x-w/2,z-d/2,x+w/2,z+d/2); return m;
}
hedge(-24.5,-3,1.6,26,1.5); hedge(24.5,8,1.6,22,1.5);
hedge(-16.5,29.5,16,1.6,1.4); hedge(16.5,29.5,16,1.6,1.4);
hedge(-28,-14,12,1.5,1.3); hedge(31,24,14,1.5,1.4);
hedge(-30,10,1.5,14,1.25); hedge(29.5,-1,1.5,10,1.2);
// topiary cones surrendering to entropy
for(const [tx,tz] of [[-15,-13],[15,-13],[-12.5,11],[12.5,11],[-23,6],[23,-13]]){
  const cone=new THREE.Mesh(new THREE.ConeGeometry(1.05,2.6,9),M.hedge); put(estate,cone,tx,1.5,tz);
  put(estate,cyl(.09,.13,.6,M.bark,7),tx,.3,tz);
  put(estate,sph(rr(.3,.5),M.leaf,7,5),tx+rr(-.7,.7),rr(1.2,2.2),tz+rr(-.7,.7));
  colC(tx,tz,1.15);
}
// ancient oaks, a dead sentinel, a fallen giant
function tree(x,z,s=1,dead=false){
  const g=new THREE.Group(); g.position.set(x,0,z); estate.add(g);
  const lean=rr(-.05,.05); g.rotation.z=lean;
  let y=0,px=0,pz=0;
  for(let i=0;i<3;i++){const seg=cyl((.42-i*.09)*s,(.55-i*.09)*s,1.9*s,M.bark,8); seg.position.set(px,y+.95*s,pz); seg.rotation.z=rr(-.1,.1); seg.castShadow=true; g.add(seg); px+=rr(-.25,.25)*s; pz+=rr(-.2,.2)*s; y+=1.75*s}
  const tops=[];
  for(let b=0;b<5;b++){
    const a=b/5*6.28+rr(-.3,.3), bl=rr(1.6,2.6)*s;
    const br=cyl(.06*s,.16*s,bl,M.bark,6);
    br.position.set(px+Math.cos(a)*bl*.32,y+bl*.3,pz+Math.sin(a)*bl*.32);
    br.rotation.set(Math.sin(a)*.9,0,-Math.cos(a)*.9); br.castShadow=true; g.add(br);
    tops.push([px+Math.cos(a)*bl*.62,y+bl*.62,pz+Math.sin(a)*bl*.62]);
  }
  if(!dead) for(const t of tops) for(let i=0;i<3;i++){
    const f=sph(rr(1.1,1.9)*s,i%2?M.leaf:M.leafDark,9,7);
    f.position.set(t[0]+rr(-.7,.7)*s,t[1]+rr(-.3,.8)*s,t[2]+rr(-.7,.7)*s); f.castShadow=true; g.add(f);
  }
  if(!dead){const f=sph(rr(1.6,2.2)*s,M.leaf,10,7); f.position.set(px,y+1.6*s,pz); f.castShadow=true; g.add(f)}
  for(let i=0;i<5;i++) put(g,sph(rr(.2,.4)*s,M.leafDark,7,5),rr(-1,1)*s,.25,rr(-1,1)*s); // root suckers
  colC(x,z,.75*s); return g;
}
tree(-33,-12,1.25); tree(-31,14,1.1); tree(-15,-15,.95); tree(33,14,1.2); tree(34,-20,1.05);
tree(16,26,.9); tree(-8,28,1.0); tree(27,28,1.15); tree(-36,2,1.3); tree(36,2,1.1,true);
tree(-14,8,.8); tree(18,-1,.85); tree(-26,-22,.9); tree(24,-22,1.0);
{ // fallen giant across the west lawn - mow around it
  const log=cyl(.42,.55,7,M.bark,9); log.rotation.z=Math.PI/2; log.rotation.y=.5; log.position.set(-27,.45,20); log.castShadow=true; estate.add(log);
  put(estate,sph(.9,M.leaf,8,6),-24.2,.8,21.6); put(estate,sph(.7,M.leafDark,8,6),-29.5,.7,18.6);
  for(let i=0;i<6;i++) colC(-30+i*1.2,20.8-i*.32,.7);
}
// classical statues: dignity vs gravity
function statue(x,z,ry,fallen=false){
  const g=new THREE.Group(); g.position.set(x,0,z); g.rotation.y=ry; estate.add(g);
  put(g,box(1.1,1.15,1.1,M.mossStone),0,.57,0); put(g,box(1.3,.18,1.3,M.stoneDark),0,1.22,0);
  const fig=new THREE.Group();
  const robe=new THREE.Mesh(new THREE.LatheGeometry([[.34,0],[.3,.5],[.2,1.0],[.24,1.25],[.12,1.45]].map(p=>new THREE.Vector2(p[0],p[1])),10),M.marble);
  put(fig,robe,0,0,0);
  if(fallen){
    fig.rotation.z=Math.PI/2-.12; fig.position.set(1.15,1.55,.2); g.add(fig);
    put(g,sph(.17,M.marble),2.45,.17,.75); // head, over there now
    put(g,cyl(.06,.07,.55,M.marble,7),1.8,.1,-.5);
  }else{
    fig.position.y=1.31; g.add(fig);
    put(fig,sph(.17,M.marble),0,1.62,0);
    put(fig,sph(.09,M.marble,8,6),0,1.76,-.1); // hair bun
    const sash=box(.09,.85,.3,M.marble); sash.position.set(.02,1.0,.1); sash.rotation.z=.5; sash.castShadow=true; fig.add(sash);
    const arm=cyl(.055,.07,.75,M.marble,7); arm.position.set(.34,1.2,.08); arm.rotation.z=-.9; arm.castShadow=true; fig.add(arm);
    const arm2=cyl(.05,.065,.62,M.marble,7); arm2.position.set(-.27,1.05,.04); arm2.rotation.z=.35; arm2.castShadow=true; fig.add(arm2);
    const moss=put(fig,sph(.13,new THREE.MeshStandardMaterial({color:0x7d9455,roughness:1}),7,5),-.16,1.28,.1); moss.scale.z=.5; // mossy shoulder
  }
  colC(x,z,1.0); return g;
}
statue(-11,-13.5,.4); statue(11,-13.5,-.4,true); statue(-16,10,1.2); statue(16,10,-1.1); statue(26,18,2.4,true);
// sundial + birdbath + stone bench + rose arch
{put(estate,cyl(.12,.22,1,M.mossStone,8),-6,.5,10); const dial=cyl(.45,.45,.06,M.brass,18); put(estate,dial,-6,1.05,10); colC(-6,10,.55);
 put(estate,cyl(.1,.2,.9,M.mossStone,8),-7.5,.45,17); put(estate,cyl(.5,.3,.18,M.mossStone,14),-7.5,.95,17); colC(-7.5,17,.55);
 const bench=box(1.9,.12,.55,M.stoneDark); put(estate,bench,-12,.5,21,.3); put(estate,box(.2,.5,.5,M.stoneDark),-12.7,.25,20.8); colC(-12,21,.9);
 for(const sx of[-1.1,1.1]){put(estate,cyl(.06,.06,2.6,M.rust,7),-21+sx,1.3,6)}
 const arch=new THREE.Mesh(new THREE.TorusGeometry(1.1,.06,7,14,Math.PI),M.rust); arch.position.set(-21,2.6,6); arch.castShadow=true; estate.add(arch);
 for(let i=0;i<16;i++){const a=i/15*Math.PI; put(estate,sph(rr(.2,.38),M.leaf,7,5),-21+Math.cos(a)*1.1,2.6+Math.sin(a)*1.1,6+rr(-.15,.15))}
 colC(-21,6,.5);}
// ruined greenhouse (east): white rusted frame, smashed panes, jungle inside
{
  const g=new THREE.Group(); g.position.set(29.5,0,-10); g.rotation.y=.12; estate.add(g);
  put(g,box(10,.25,7,M.stoneDark),0,.12,0);
  const glassM=new THREE.MeshPhysicalMaterial({color:0xcfe4da,transparent:true,opacity:.32,roughness:.12,metalness:.1,side:THREE.DoubleSide});
  for(let i=0;i<=5;i++){const fx=-5+i*2; put(g,box(.12,2.6,.12,M.rust),fx,1.3,-3.4); put(g,box(.12,2.6,.12,M.rust),fx,1.3,3.4);
    const rafter=box(.1,.1,4.4,M.rust); rafter.position.set(fx,3.35,-1.7); rafter.rotation.x=.72; rafter.castShadow=true; g.add(rafter);
    const rafter2=rafter.clone(); rafter2.position.z=1.7; rafter2.rotation.x=-.72; g.add(rafter2);}
  put(g,box(10.2,.14,.14,M.rust),0,2.6,-3.4); put(g,box(10.2,.14,.14,M.rust),0,2.6,3.4); put(g,box(10.2,.14,.14,M.rust),0,4.35,0);
  for(let i=0;i<14;i++){ if(rnd()<.45) continue; // smashed
    const pane=new THREE.Mesh(new THREE.PlaneGeometry(1.8,2.4),glassM);
    pane.position.set(-4+(i%5)*2,1.35,i<7?-3.38:3.38); pane.rotation.x=rr(-.03,.03); g.add(pane);}
  for(let i=0;i<8;i++){ if(rnd()<.5) continue;
    const pane=new THREE.Mesh(new THREE.PlaneGeometry(1.8,2.2),glassM);
    pane.position.set(-4+(i%4)*2.4,3.4,i<4?-1.7:1.7); pane.rotation.x=(i<4?.72:-.72)+rr(-.05,.05); g.add(pane);}
  for(let i=0;i<10;i++){put(g,sph(rr(.5,1.1),M.leaf,8,6),rr(-4.4,4.4),rr(.6,1.4),rr(-2.8,2.8));
    put(g,cyl(.2,.15,.35,M.rust,8),rr(-4.4,4.4),.42,rr(-2.8,2.8))}
  const shard=box(.8,.03,1.1,glassM); shard.position.set(2,.3,4.3); shard.rotation.set(.3,.6,.2); g.add(shard);
}
// pond (SW): mirror-dark, lilies, a heron of stone
{
  const pond=new THREE.Mesh(new THREE.CircleGeometry(6.4,28),new THREE.MeshStandardMaterial({color:0x2e4438,roughness:.08,metalness:.25}));
  pond.rotation.x=-Math.PI/2; pond.position.set(-29,.03,22); pond.scale.set(1.12,.8,1); pond.receiveShadow=true; estate.add(pond);
  const rim=new THREE.Mesh(new THREE.RingGeometry(6.1,7,28),M.gravel); rim.rotation.x=-Math.PI/2; rim.position.set(-29,.02,22); rim.scale.set(1.1,.82,1); estate.add(rim);
  for(let i=0;i<16;i++){const pad=new THREE.Mesh(new THREE.CircleGeometry(rr(.2,.45),9),new THREE.MeshStandardMaterial({color:0x4f7530,roughness:.7}));
    pad.rotation.x=-Math.PI/2; const a=rr(0,6.3),rd=rr(.5,4.6); pad.position.set(-29+Math.cos(a)*rd*1.1,.06,22+Math.sin(a)*rd*.78); estate.add(pad)}
  put(estate,cyl(.05,.07,1.1,M.marble,6),-24.4,.55,19.5);
  const heron=sph(.22,M.marble,8,6); heron.position.set(-24.4,1.25,19.5); heron.scale.set(1,.8,1.5); heron.castShadow=true; estate.add(heron);
}
// perimeter: crumbling stone walls, iron railings, the great gate (rusted ajar)
function wallRun(x0,z0,x1,z1){
  const len=Math.hypot(x1-x0,z1-z0), n=Math.round(len/3.2);
  for(let i=0;i<n;i++){
    const t=(i+.5)/n, wx=lerp(x0,x1,t), wz=lerp(z0,z1,t), gap=rnd()<.12;
    const h=gap?rr(.3,.7):rr(1.15,1.45);
    const w=box(3.25,h,.55,M.stone); put(estate,w,wx,h/2,wz,Math.atan2(x1-x0,z1-z0)+Math.PI/2+rr(-.015,.015));
    if(!gap&&rnd()<.5) put(estate,sph(rr(.3,.55),M.leafDark,7,5),wx,h+.1,wz);
  }
  colB(Math.min(x0,x1)-.4,Math.min(z0,z1)-.4,Math.max(x0,x1)+.4,Math.max(z0,z1)+.4);
}
wallRun(-40,-34,40,-34); wallRun(-40,-34,-40,34); wallRun(40,-34,40,34);
wallRun(-40,34,-4.4,34); wallRun(4.4,34,40,34);
{ // gate pillars + gates + beer crate by the entrance (the supply drop)
  for(const sx of[-4.4,4.4]){put(estate,box(1,3.1,1,M.stone),sx,1.55,34); put(estate,sph(.42,M.stoneDark),sx,3.45,34); colC(sx,34,.8)}
  for(const sx of[-1,1]){
    const gate=new THREE.Group(); gate.position.set(sx*4.4,0,34); estate.add(gate);
    for(let b=0;b<7;b++) put(gate,cyl(.035,.035,2.3,M.iron,6),-sx*(.35+b*.58),1.15,0);
    put(gate,box(4.1,.09,.09,M.iron),-sx*2.05,2.15,0); put(gate,box(4.1,.09,.09,M.iron),-sx*2.05,.4,0);
    gate.rotation.y=sx*rr(.5,.85); // hanging open, welcoming heroes
  }
  const crate=box(.62,.34,.44,M.wood); put(estate,crate,3.4,.17,31.6,.4); colC(3.4,31.6,.55);
  for(let i=0;i<6;i++){const b=cyl(.045,.05,.26,new THREE.MeshStandardMaterial({color:0x5a3410,roughness:.15,metalness:.2}),8);
    b.position.set(3.22+(i%3)*.17,.42,31.5+((i/3)|0)*.18); b.castShadow=true; estate.add(b)}
}
// clouds drifting
const clouds=[];
for(let i=0;i<13;i++){
  const g=new THREE.Group(); const cm=new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xffffff,emissiveIntensity:.3,roughness:1,transparent:true,opacity:.9});
  for(let p=0;p<5;p++){const s=sph(rr(2.2,4.6),cm,10,7); s.position.set(p*rr(2,3.4)-6,rr(-.5,.7),rr(-1.6,1.6)); s.scale.y=.48; g.add(s)}
  g.position.set(rr(-140,140),rr(38,58),rr(-130,110)); scene.add(g); clouds.push(g);
}

// ---------- THE GRASS: ~13,000 wind-blown tufts, every one cuttable ----------
function bladeTuftGeometry(){
  const pos=[],nor=[],col=[],uvA=[],idx=[]; let vi=0;
  const BLADES=7, SEG=3;
  for(let b=0;b<BLADES;b++){
    const a=rnd()*Math.PI*2, ox=Math.cos(a)*rr(0,.16), oz=Math.sin(a)*rr(0,.16);
    const dirx=Math.cos(a), dirz=Math.sin(a);           // blade faces outward, bends outward
    const px=-dirz, pz=dirx;                            // width axis
    const w0=rr(.02,.034), bend=rr(.16,.38), hVar=rr(.74,1.1);
    const tintR=rr(.8,1.02), tintB=rr(.7,.95);
    for(let s=0;s<=SEG;s++){
      const t=s/SEG, y=t*hVar, wdt=w0*(1-t*.88), bendOff=bend*t*t;
      const cxp=ox+dirx*bendOff, czp=oz+dirz*bendOff;
      pos.push(cxp-px*wdt,y,czp-pz*wdt, cxp+px*wdt,y,czp+pz*wdt);
      nor.push(dirx,.72,dirz, dirx,.72,dirz);
      const shade=.36+.64*t;                             // dark root -> sunlit tip
      col.push(shade*tintR,shade,shade*tintB, shade*tintR,shade,shade*tintB);
      uvA.push(0,t, 1,t);
      if(s<SEG){const k=vi+s*2; idx.push(k,k+1,k+2, k+1,k+3,k+2)}
    }
    vi+=(SEG+1)*2;
  }
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
  g.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));
  g.setAttribute('color',new THREE.Float32BufferAttribute(col,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uvA,2));
  g.setIndex(idx); return g;
}
const grassTime={value:0};
const grassMat=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
grassMat.onBeforeCompile=sh=>{
  sh.uniforms.uTime=grassTime;
  sh.vertexShader='uniform float uTime;\n'+sh.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
    float swayAmt=transformed.y*transformed.y;
    vec4 ipos=instanceMatrix*vec4(0.,0.,0.,1.);
    float ph=ipos.x*.35+ipos.z*.27;
    transformed.x+=(sin(uTime*1.6+ph)+sin(uTime*2.7+ph*1.7)*.4)*.055*swayAmt;
    transformed.z+=cos(uTime*1.25+ph)*.04*swayAmt;`);
};
const GRASS_POS=[],GRASS_TALL=[],GRASS_ROT=[];
{
  const step=.5;
  for(let x=LAWN.x0+1;x<LAWN.x1-1;x+=step)for(let z=LAWN.z0+1;z<LAWN.z1-1;z+=step){
    const jx=x+rr(-.24,.24), jz=z+rr(-.24,.24);
    if(!isGrass(jx,jz)) continue;
    let blocked=false;
    for(const b of COL_B){if(jx>b.x0-.1&&jx<b.x1+.1&&jz>b.z0-.1&&jz<b.z1+.1){blocked=true;break}}
    if(blocked) continue;
    for(const c of COL_C){if(Math.hypot(jx-c.x,jz-c.z)<c.r*.82){blocked=true;break}}
    if(blocked) continue;
    const patch=.72+.5*(0.5+0.5*Math.sin(jx*.16+2.1)*Math.sin(jz*.13-1.2)); // meadow patchiness
    GRASS_POS.push(jx,jz); GRASS_TALL.push(rr(.55,.98)*patch); GRASS_ROT.push(rnd()*6.28);
  }
}
const GRASS_N=GRASS_TALL.length;
const grassMesh=new THREE.InstancedMesh(bladeTuftGeometry(),grassMat,GRASS_N);
grassMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
grassMesh.frustumCulled=false; grassMesh.receiveShadow=true;
const GRASS_CUT=new Uint8Array(GRASS_N);
const _m4=new THREE.Matrix4(),_q=new THREE.Quaternion(),_e=new THREE.Euler(),_v=new THREE.Vector3(),_s=new THREE.Vector3(),_c=new THREE.Color();
function grassMatrix(i,hScale){
  _e.set(0,GRASS_ROT[i],0); _q.setFromEuler(_e);
  _v.set(GRASS_POS[i*2],0,GRASS_POS[i*2+1]);
  const w=.95+((i*37)%10)*.06;
  _s.set(w,GRASS_TALL[i]*hScale,w);
  _m4.compose(_v,_q,_s); grassMesh.setMatrixAt(i,_m4);
}
function grassColor(i,cut){
  if(cut) _c.setHSL(.26,.62,rr(.4,.48));
  else{
    const dry=((i*53)%17)/17;
    if(dry>.86) _c.setHSL(.13,.5,rr(.42,.5));            // straw-dry patches
    else _c.setHSL(rr(.22,.29),rr(.5,.72),rr(.26,.4));
  }
  grassMesh.setColorAt(i,_c);
}
for(let i=0;i<GRASS_N;i++){grassMatrix(i,1);grassColor(i,false)}
grassMesh.instanceColor.needsUpdate=true; scene.add(grassMesh);
// spatial hash for the mower deck
const GHASH=new Map(), GCELL=2;
const gkey=(x,z)=>((x/GCELL)|0)+','+((z/GCELL)|0);
for(let i=0;i<GRASS_N;i++){const k=gkey(GRASS_POS[i*2],GRASS_POS[i*2+1]); if(!GHASH.has(k))GHASH.set(k,[]); GHASH.get(k).push(i)}
let cutCount=0, cutThisFrame=0, tallNear=0;
const falling=[]; // tufts mid-collapse {i,t}
function cutAt(cx,cz,yawF,yawR,halfW=.78,lenF=1.05,lenB=.75){
  cutThisFrame=0; tallNear=0;
  const fx=Math.sin(yawF),fz=Math.cos(yawF), rx=Math.sin(yawR),rz=Math.cos(yawR);
  const x0=((cx-2.4)/GCELL)|0,x1=((cx+2.4)/GCELL)|0,z0=((cz-2.4)/GCELL)|0,z1=((cz+2.4)/GCELL)|0;
  for(let gx=x0;gx<=x1;gx++)for(let gz=z0;gz<=z1;gz++){
    const cell=GHASH.get(gx+','+gz); if(!cell) continue;
    for(const i of cell){
      const dx=GRASS_POS[i*2]-cx, dz=GRASS_POS[i*2+1]-cz;
      const along=dx*fx+dz*fz, side=dx*rx+dz*rz;
      if(along>-lenB&&along<lenF&&Math.abs(side)<halfW){
        if(!GRASS_CUT[i]){
          GRASS_CUT[i]=1; cutCount++; cutThisFrame++;
          falling.push({i,t:0,h:GRASS_TALL[i]});
          grassColor(i,true);
          if(cutThisFrame%3===0) spawnClippings(GRASS_POS[i*2],GRASS_POS[i*2+1],2);
        }
      } else if(!GRASS_CUT[i]&&along>0&&along<2.2&&Math.abs(side)<1.3) tallNear++;
    }
  }
  if(cutThisFrame>0) grassMesh.instanceColor.needsUpdate=true;
}
function updateFalling(dt){
  if(!falling.length) return;
  let dirty=false;
  for(let k=falling.length-1;k>=0;k--){
    const f=falling[k]; f.t+=dt*4.2; dirty=true;
    if(f.t>=1){grassMatrix(f.i,.15); falling.splice(k,1)}
    else grassMatrix(f.i,lerp(1,.15,smooth(f.t)));
  }
  if(dirty) grassMesh.instanceMatrix.needsUpdate=true;
}
// wildflower heads riding the jungle (daisies, poppies, dandelion clocks, thistles)
const FLOWER_N=850;
const flowerMesh=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.048,1),new THREE.MeshStandardMaterial({roughness:.7,flatShading:true}),FLOWER_N);
flowerMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); flowerMesh.frustumCulled=false;
const FLOWER_POS=[], FLOWER_ORIG=[];
{
  const cols=[0xffffff,0xffd93c,0xe8443a,0xc77ac2,0xff9a3c,0xf2f2ea];
  let placed=0,guard=0;
  while(placed<FLOWER_N&&guard++<9000){
    const x=rr(LAWN.x0+2,LAWN.x1-2), z=rr(LAWN.z0+2,LAWN.z1-2);
    if(!isGrass(x,z)) continue;
    FLOWER_POS.push(x,z);
    const fy=rr(.3,.62), fs=rr(.55,1.15), fr=rnd()*6.3; FLOWER_ORIG.push(fy,fs,fr);
    _e.set(0,fr,0);_q.setFromEuler(_e);_v.set(x,fy,z);_s.setScalar(fs);
    _m4.compose(_v,_q,_s); flowerMesh.setMatrixAt(placed,_m4);
    flowerMesh.setColorAt(placed,_c.setHex(cols[(rnd()*cols.length)|0]));
    placed++;
  }
  flowerMesh.count=placed;
  if(flowerMesh.instanceColor) flowerMesh.instanceColor.needsUpdate=true;
  scene.add(flowerMesh);
}
const FLOWER_CUT=new Uint8Array(FLOWER_N);
function cutFlowers(cx,cz){
  for(let i=0;i<flowerMesh.count;i++){
    if(FLOWER_CUT[i]) continue;
    if(Math.hypot(FLOWER_POS[i*2]-cx,FLOWER_POS[i*2+1]-cz)<1.05){
      FLOWER_CUT[i]=1; _m4.makeScale(0,0,0); _m4.setPosition(FLOWER_POS[i*2],-1,FLOWER_POS[i*2+1]);
      flowerMesh.setMatrixAt(i,_m4); flowerMesh.instanceMatrix.needsUpdate=true;
      spawnClippings(FLOWER_POS[i*2],FLOWER_POS[i*2+1],1,0xffe27a);
    }
  }
}

// ---------- particles: clippings cannon, smoke, pollen, wildlife ----------
const CLIP_N=700;
const clipMesh=new THREE.InstancedMesh(new THREE.BoxGeometry(.11,.018,.03),new THREE.MeshLambertMaterial({color:0xffffff}),CLIP_N);
clipMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); clipMesh.frustumCulled=false; scene.add(clipMesh);
const clips=[]; for(let i=0;i<CLIP_N;i++){clips.push({life:0,x:0,y:-5,z:0,vx:0,vy:0,vz:0,rx:0,ry:0,sp:0});_m4.makeScale(0,0,0);_m4.setPosition(0,-5,0);clipMesh.setMatrixAt(i,_m4);clipMesh.setColorAt(i,_c.setHSL(.26,.6,.38))}
let clipHead=0;
function spawnClippings(x,z,n=2,tint=0){
  for(let k=0;k<n;k++){
    const c=clips[clipHead]; const id=clipHead; clipHead=(clipHead+1)%CLIP_N;
    const a=rnd()*6.28, sp=rr(1.2,3.6);
    Object.assign(c,{life:rr(.7,1.4),x:x+rr(-.15,.15),y:rr(.18,.3),z:z+rr(-.15,.15),vx:Math.cos(a)*sp,vy:rr(1.6,3.4),vz:Math.sin(a)*sp,rx:rnd()*6,ry:rnd()*6,sp:rr(4,13)});
    if(tint) clipMesh.setColorAt(id,_c.setHex(tint)); else clipMesh.setColorAt(id,_c.setHSL(rr(.2,.3),.65,rr(.3,.5)));
  }
  if(clipMesh.instanceColor) clipMesh.instanceColor.needsUpdate=true;
}
function updateClips(dt){
  let any=false;
  for(let i=0;i<CLIP_N;i++){const c=clips[i]; if(c.life<=0) continue; any=true;
    c.life-=dt; c.vy-=7.5*dt; c.x+=c.vx*dt; c.y+=c.vy*dt; c.z+=c.vz*dt;
    if(c.y<.03){c.y=.03;c.vy*=-.22;c.vx*=.6;c.vz*=.6}
    c.rx+=c.sp*dt; c.ry+=c.sp*.7*dt;
    const sc=c.life<.25?c.life/.25:1;
    _e.set(c.rx,c.ry,0);_q.setFromEuler(_e);_v.set(c.x,c.y,c.z);_s.setScalar(Math.max(.001,sc));
    _m4.compose(_v,_q,_s); clipMesh.setMatrixAt(i,_m4);
    if(c.life<=0){_m4.makeScale(0,0,0);_m4.setPosition(0,-5,0);clipMesh.setMatrixAt(i,_m4)}
  }
  if(any) clipMesh.instanceMatrix.needsUpdate=true;
}
// soft smoke sprite pool (cigar ribbon, exhales, exhaust puffs)
const SMOKE_N=150, smokes=[];
for(let i=0;i<SMOKE_N;i++){
  const mat=new THREE.SpriteMaterial({map:softTex,color:0xd8d8d8,transparent:true,opacity:0,depthWrite:false});
  const s=new THREE.Sprite(mat); s.scale.setScalar(.1); s.position.set(0,-10,0); scene.add(s);
  smokes.push({s,life:0,max:1,vx:0,vy:0,vz:0,grow:1,op:.4,ph:rnd()*6.3});
}
let smokeHead=0;
function spawnSmoke(x,y,z,vx,vy,vz,size,life,opacity,tint=0xdcdcdc,grow=1.6){
  const p=smokes[smokeHead]; smokeHead=(smokeHead+1)%SMOKE_N;
  Object.assign(p,{life,max:life,vx,vy,vz,grow,op:opacity});
  p.s.position.set(x,y,z); p.s.scale.setScalar(size); p.s.material.color.setHex(tint); p.s.material.opacity=opacity;
  p.s.material.rotation=rnd()*6.3;
}
function updateSmoke(dt,t){
  for(const p of smokes){ if(p.life<=0) continue;
    p.life-=dt; const k=1-p.life/p.max;
    p.s.position.x+=(p.vx+Math.sin(t*2.1+p.ph)*.16)*dt;
    p.s.position.y+=p.vy*dt; p.s.position.z+=(p.vz+Math.cos(t*1.7+p.ph)*.16)*dt;
    p.s.scale.addScalar(p.grow*dt*.55);
    p.s.material.opacity=p.op*(k<.15?k/.15:1-(k-.15)/.85);
    p.s.material.rotation+=dt*.25;
    if(p.life<=0){p.s.material.opacity=0;p.s.position.y=-10}
  }
}
// golden pollen motes in the evening light
let pollen;
{ const n=320, arr=new Float32Array(n*3);
  for(let i=0;i<n;i++){arr[i*3]=rr(-42,42);arr[i*3+1]=rr(.3,5.5);arr[i*3+2]=rr(-34,34)}
  const g=new THREE.BufferGeometry(); g.setAttribute('position',new THREE.BufferAttribute(arr,3));
  pollen=new THREE.Points(g,new THREE.PointsMaterial({map:softTex,color:0xffe9a0,size:.13,transparent:true,opacity:.55,depthWrite:false,sizeAttenuation:true}));
  scene.add(pollen);
}
// butterflies over the jungle + swifts overhead
const butterflies=[], birds=[];
for(let i=0;i<9;i++){
  const g=new THREE.Group(); const cm=new THREE.MeshStandardMaterial({color:[0xff8c3a,0xf2ead0,0x7aa6e8,0xe87ab0][i%4],side:THREE.DoubleSide,roughness:.7});
  const w1=new THREE.Mesh(new THREE.PlaneGeometry(.17,.13),cm); w1.position.x=-.085;
  const w2=w1.clone(); w2.position.x=.085;
  const p1=new THREE.Group(); p1.add(w1); const p2=new THREE.Group(); p2.add(w2);
  g.add(p1,p2); g.position.set(rr(-25,25),rr(.8,1.7),rr(-15,25)); scene.add(g);
  butterflies.push({g,p1,p2,a:rnd()*6.3,ph:rnd()*6.3,sp:rr(.7,1.3)});
}
for(let i=0;i<6;i++){
  const g=new THREE.Group(); const bm=new THREE.MeshStandardMaterial({color:0x2b2f36,side:THREE.DoubleSide,roughness:.9});
  const body=new THREE.Mesh(new THREE.ConeGeometry(.09,.7,6),bm); body.rotation.x=Math.PI/2; g.add(body);
  const w1=new THREE.Mesh(new THREE.PlaneGeometry(.85,.22),bm); w1.position.x=-.45;
  const w2=w1.clone(); w2.position.x=.45;
  const p1=new THREE.Group(); p1.add(w1); const p2=new THREE.Group(); p2.add(w2); g.add(p1,p2);
  scene.add(g); birds.push({g,p1,p2,ph:i/6*6.28,r:rr(34,58),h:rr(24,34),sp:rr(.05,.09)});
}
function updateWildlife(dt,t,mx,mz){
  for(const b of butterflies){
    b.a+=Math.sin(t*.6+b.ph)*1.3*dt;
    const dm=Math.hypot(b.g.position.x-mx,b.g.position.z-mz);
    if(dm<3.5) b.a=Math.atan2(b.g.position.x-mx,b.g.position.z-mz); // scatter!
    b.g.position.x+=Math.sin(b.a)*b.sp*dt; b.g.position.z+=Math.cos(b.a)*b.sp*dt;
    b.g.position.y=1.1+Math.sin(t*2.2+b.ph)*.4+(dm<3.5?.6:0);
    b.g.position.x=clamp(b.g.position.x,-38,38); b.g.position.z=clamp(b.g.position.z,-30,32);
    b.g.rotation.y=b.a;
    const flap=Math.sin(t*17+b.ph)*.95; b.p1.rotation.z=flap; b.p2.rotation.z=-flap;
  }
  for(const b of birds){
    b.ph+=b.sp*dt*3;
    b.g.position.set(Math.cos(b.ph)*b.r,b.h+Math.sin(t*.7+b.ph*3)*1.4,Math.sin(b.ph)*b.r*.75);
    b.g.rotation.y=-b.ph; const flap=Math.sin(t*7+b.ph*9)*.5; b.p1.rotation.z=flap; b.p2.rotation.z=-flap;
  }
  pollen.rotation.y=t*.004; pollen.position.y=Math.sin(t*.4)*.15;
  for(const c of clouds){c.position.x+=dt*.55; if(c.position.x>170)c.position.x=-170}
  fountainWater.position.y=.66+Math.sin(t*1.8)*.006;
}

// ---------- THE TURF TITAN 5000: ride-on mower tractor (+Z = forward) ----------
const mower=new THREE.Group(); scene.add(mower);
const decalTex=ctex(512,128,(x,w,h)=>{x.clearRect(0,0,w,h);x.font='italic 900 58px Archivo,Arial';x.fillStyle='#ffe9a8';x.strokeStyle='#5a0f08';x.lineWidth=8;
  x.strokeText('TURF TITAN',14,56);x.fillText('TURF TITAN',14,56);x.font='italic 900 44px Archivo,Arial';x.fillStyle='#fff';x.strokeText('5000 GT',120,108);x.fillText('5000 GT',120,108)});
const dashTex=ctex(256,128,(x,w,h)=>{x.fillStyle='#15161a';x.fillRect(0,0,w,h);
  for(const [gx,label] of [[56,'RPM'],[200,'MPH']]){
    x.fillStyle='#ece5d0';x.beginPath();x.arc(gx,58,40,0,6.3);x.fill();x.strokeStyle='#888';x.lineWidth=3;x.stroke();
    x.fillStyle='#23252a';for(let i=0;i<=8;i++){const a=Math.PI*.75+i/8*Math.PI*1.5;x.save();x.translate(gx+Math.cos(a)*31,58+Math.sin(a)*31);x.rotate(a+Math.PI/2);x.fillRect(-1.5,-6,3,8);x.restore()}
    x.font='800 13px Arial';x.textAlign='center';x.fillText(label,gx,92);
    x.fillStyle='#b02018';x.beginPath();x.arc(gx+Math.cos(2)*31,58+Math.sin(2)*31,4,0,6.3);x.fill();
  }
  x.fillStyle='#ffbe3c';x.font='800 11px Arial';x.fillText('TURF TITAN',128,40);
  x.fillStyle='#3ddc5a';x.beginPath();x.arc(128,66,5,0,6.3);x.fill();
  x.fillStyle='#e8b13c';x.beginPath();x.arc(112,66,5,0,6.3);x.fill();x.fillStyle='#c23b2e';x.beginPath();x.arc(144,66,5,0,6.3);x.fill();});
const wheelPivots=[], wheelSpin=[];
function makeWheel(r,w){
  const g=new THREE.Group(); const spin=new THREE.Group(); g.add(spin);
  const tyre=new THREE.Mesh(new THREE.CylinderGeometry(r,r,w,22),M.tyre); tyre.rotation.z=Math.PI/2; tyre.castShadow=true; spin.add(tyre);
  const hub=new THREE.Mesh(new THREE.CylinderGeometry(r*.5,r*.5,w+.02,14),M.chrome); hub.rotation.z=Math.PI/2; spin.add(hub);
  for(let i=0;i<6;i++){const bolt=new THREE.Mesh(new THREE.CylinderGeometry(r*.07,r*.07,w+.05,6),M.iron);bolt.rotation.z=Math.PI/2;bolt.position.set(0,Math.cos(i*1.047)*r*.3,Math.sin(i*1.047)*r*.3);spin.add(bolt)}
  wheelSpin.push(spin); return g;
}
let steeringWheel,bladeDisc,exhaustTip,rpmNeedle,mphNeedle,throttleLever;
{
  // chassis + deck + side discharge chute (clippings cannon)
  put(mower,rbox(.62,.3,1.9,.07,M.iron),0,.48,-.05);
  const deck=rbox(1.55,.2,1.15,.08,new THREE.MeshStandardMaterial({color:0x7c1710,roughness:.45,metalness:.3})); put(mower,deck,0,.2,.28);
  put(mower,box(1.5,.06,1.05,M.blackPlastic),0,.32,.28);
  const chute=rbox(.5,.16,.6,.04,M.blackPlastic); chute.position.set(.95,.26,.35); chute.rotation.z=.28; chute.castShadow=true; mower.add(chute);
  bladeDisc=new THREE.Mesh(new THREE.CircleGeometry(.66,24),new THREE.MeshStandardMaterial({color:0x9aa2a8,transparent:true,opacity:.35,side:THREE.DoubleSide,roughness:.3,metalness:.8}));
  bladeDisc.rotation.x=-Math.PI/2; bladeDisc.position.set(0,.09,.28); mower.add(bladeDisc);
  for(const sx of[-.62,.62]){const aw=cyl(.07,.07,.05,M.blackPlastic,10); aw.rotation.z=Math.PI/2; aw.position.set(sx,.07,.85); mower.add(aw)}
  // hood: long, glossy, vented — the view over it is half the game
  const hood=rbox(.64,.4,1.05,.12,M.redPaint); put(mower,hood,0,.82,.92);
  const hoodTop=rbox(.5,.1,.85,.05,M.redPaint); put(mower,hoodTop,0,1.05,.92);
  put(mower,box(.075,.022,.78,M.blackPlastic),0,1.105,.92); // centre spine
  for(let v=0;v<4;v++){put(mower,box(.13,.014,.035,M.blackPlastic),-.16,1.102,.68+v*.13); put(mower,box(.13,.014,.035,M.blackPlastic),.16,1.102,.68+v*.13)}
  const warnTex=ctex(128,64,(x,w,h)=>{x.fillStyle='#f2c230';x.fillRect(0,0,w,h);x.fillStyle='#1c1c1c';x.font='900 17px Arial';x.textAlign='center';x.fillText('⚠ TITAN',w/2,25);x.font='800 10px Arial';x.fillText('KEEP BEER CLEAR',w/2,42);x.fillText('OF MOVING BLADES',w/2,55)});
  const warn=new THREE.Mesh(new THREE.PlaneGeometry(.13,.065),new THREE.MeshStandardMaterial({map:warnTex,roughness:.6}));
  warn.rotation.x=-Math.PI/2; warn.rotation.z=Math.PI; warn.position.set(.14,1.112,.58); mower.add(warn);
  for(const sx of[-1,1]){
    for(let v=0;v<4;v++) put(mower,box(.02,.035,.5,M.blackPlastic),sx*.325,.86+v*.07,.85); // side vents
    const decal=new THREE.Mesh(new THREE.PlaneGeometry(.62,.155),new THREE.MeshStandardMaterial({map:decalTex,transparent:true,roughness:.35,polygonOffset:true,polygonOffsetFactor:-1}));
    decal.position.set(sx*.328,.7,1.0); decal.rotation.y=sx*Math.PI/2; mower.add(decal);
  }
  const grille=rbox(.56,.42,.1,.04,M.blackPlastic); put(mower,grille,0,.72,1.47);
  for(let b=0;b<5;b++) put(mower,box(.48,.035,.03,M.chrome),0,.58+b*.08,1.52);
  put(mower,cyl(.07,.07,.03,M.brass,16),0,.93,1.52).rotation.x=Math.PI/2;
  for(const sx of[-1,1]){
    const light=cyl(.075,.085,.06,new THREE.MeshStandardMaterial({color:0xfff3c4,emissive:0xffdf8e,emissiveIntensity:1.4,roughness:.2}),14);
    light.rotation.x=Math.PI/2; light.position.set(sx*.24,.94,1.44); mower.add(light);
    put(mower,cyl(.09,.09,.05,M.chrome,14),sx*.24,.94,1.41).rotation.x=Math.PI/2;
  }
  put(mower,rbox(.8,.14,.12,.04,M.chrome),0,.34,1.5); // front bumper
  // exhaust stack with rain cap
  const stack=cyl(.027,.032,.36,M.iron,10); put(mower,stack,-.29,1.16,1.08);
  const cap=box(.075,.013,.075,M.rust); cap.position.set(-.29,1.36,1.1); cap.rotation.z=.3; mower.add(cap);
  exhaustTip=new THREE.Object3D(); exhaustTip.position.set(-.29,1.35,1.08); mower.add(exhaustTip);
  put(mower,cyl(.068,.082,.1,M.blackPlastic,12),.25,1.07,.95); // air filter can
  put(mower,cyl(.05,.05,.04,M.chrome,10),0,1.13,1.12);          // fuel cap
  // dash cowl + gauges with live needles
  const cowl=rbox(.62,.3,.32,.08,M.redPaint); put(mower,cowl,0,.9,.43);
  const dash=new THREE.Mesh(new THREE.PlaneGeometry(.52,.26),new THREE.MeshStandardMaterial({map:dashTex,roughness:.9,envMapIntensity:.12}));
  dash.position.set(0,1.0,.255); dash.rotation.x=.42; dash.rotation.y=Math.PI; mower.add(dash);
  function needle(x){const n=box(.008,.075,.004,new THREE.MeshStandardMaterial({color:0xc02018})); n.geometry.translate(0,.032,0);
    const holder=new THREE.Group(); holder.position.set(x,1.012,.242); holder.rotation.x=.42; n.castShadow=false; holder.add(n); mower.add(holder); return holder}
  rpmNeedle=needle(.146); mphNeedle=needle(-.146);
  // steering column + wheel (palms live at 5 and 7 o'clock)
  const col=cyl(.03,.035,.55,M.iron,10); col.position.set(0,.85,.28); col.rotation.x=.5; mower.add(col);
  steeringWheel=new THREE.Group(); steeringWheel.position.set(0,1.07,.18); steeringWheel.rotation.x=-.5; mower.add(steeringWheel);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(.215,.021,12,36),M.blackPlastic); rim.castShadow=true; steeringWheel.add(rim);
  for(let s=0;s<3;s++){const spoke=box(.028,.2,.018,M.iron); spoke.position.y=-.09; const hold=new THREE.Group(); hold.rotation.z=s*2.094; hold.add(spoke); steeringWheel.add(hold)}
  const hubc=cyl(.05,.05,.05,M.chrome,12); hubc.rotation.x=Math.PI/2; steeringWheel.add(hubc);
  throttleLever=new THREE.Group(); throttleLever.position.set(-.29,.92,.32); mower.add(throttleLever);
  const tRod=cyl(.012,.012,.22,M.chrome,8); tRod.position.y=.09; throttleLever.add(tRod);
  put(throttleLever,sph(.024,new THREE.MeshStandardMaterial({color:0xc02018,roughness:.35})),0,.21,0);
  // seat on springs, fenders, footboards, pedals
  put(mower,cyl(.06,.08,.3,M.iron,8),0,.55,-.62);
  for(let s=0;s<3;s++){const coil=new THREE.Mesh(new THREE.TorusGeometry(.07,.014,6,14),M.chrome); coil.position.set(0,.66+s*.05,-.62); coil.rotation.x=Math.PI/2; mower.add(coil)}
  const seatBase=rbox(.55,.13,.5,.05,M.blackPlastic); put(mower,seatBase,0,.8,-.62);
  const seatBack=rbox(.55,.55,.12,.05,M.blackPlastic); seatBack.position.set(0,1.14,-.88); seatBack.rotation.x=.14; seatBack.castShadow=true; mower.add(seatBack);
  for(let rib=0;rib<3;rib++) put(mower,box(.46,.03,.02,new THREE.MeshStandardMaterial({color:0x2c2e33,roughness:.7})),0,1.02+rib*.13,-.815+rib*.018);
  const seatDecal=new THREE.Mesh(new THREE.PlaneGeometry(.42,.105),new THREE.MeshStandardMaterial({map:decalTex,transparent:true,roughness:.5,polygonOffset:true,polygonOffsetFactor:-1}));
  seatDecal.position.set(0,1.22,-.945); seatDecal.rotation.y=Math.PI; seatDecal.rotation.x=-.14; mower.add(seatDecal);
  for(const sx of[-1,1]){
    const fender=rbox(.3,.09,1.0,.04,M.redPaint); fender.position.set(sx*.6,.82,-.68); fender.castShadow=true; mower.add(fender);
    const board=rbox(.3,.05,.65,.02,M.iron); put(mower,board,sx*.47,.34,.08);
    for(let g2=0;g2<4;g2++) put(mower,box(.24,.015,.035,M.blackPlastic),sx*.47,.375,-.12+g2*.13);
  }
  put(mower,box(.16,.03,.1,M.iron),.28,.42,.34).rotation.x=-.5; put(mower,box(.16,.03,.1,M.iron),-.28,.42,.34).rotation.x=-.5;
  // roll bar + cooler of infinite cold ones
  for(const sx of[-1,1]){const bar=cyl(.028,.028,1.05,M.iron,8); bar.position.set(sx*.42,1.1,-1.05); bar.rotation.x=.12; bar.castShadow=true; mower.add(bar)}
  const barTop=cyl(.028,.028,.88,M.iron,8); barTop.rotation.z=Math.PI/2; barTop.position.set(0,1.62,-1.11); mower.add(barTop);
  const cooler=rbox(.42,.3,.3,.03,new THREE.MeshStandardMaterial({color:0xe8e2d2,roughness:.5})); put(mower,cooler,.52,.62,-1.0);
  put(mower,rbox(.44,.07,.32,.03,new THREE.MeshStandardMaterial({color:0xb02018,roughness:.4})),.52,.79,-1.0);
  // wheels: fronts steer, all spin
  const fl=makeWheel(.26,.15); fl.position.set(-.57,.26,.92); mower.add(fl); wheelPivots.push(fl);
  const fr=makeWheel(.26,.15); fr.position.set(.57,.26,.92); mower.add(fr); wheelPivots.push(fr);
  const rl=makeWheel(.39,.23); rl.position.set(-.6,.39,-.7); mower.add(rl);
  const rrw=makeWheel(.39,.23); rrw.position.set(.6,.39,-.7); mower.add(rrw);
  // your legs + boots, living the dream on the footboards
  for(const sx of[-1,1]){
    const thigh=cyl(.075,.085,.5,M.jeans,9); thigh.position.set(sx*.19,.72,-.32); thigh.rotation.x=1.25; thigh.castShadow=true; mower.add(thigh);
    const shin=cyl(.06,.07,.42,M.jeans,9); shin.position.set(sx*.24,.48,-.02); shin.rotation.x=.25; mower.add(shin);
    const boot=rbox(.11,.09,.27,.03,new THREE.MeshStandardMaterial({color:0x4a3018,roughness:.7})); put(mower,boot,sx*.3,.4,.16);
  }
}
// chase-cam-only body (head/torso hidden in first person)
const driverBody=new THREE.Group(); driverBody.visible=false; mower.add(driverBody);
{
  const torso=rbox(.44,.62,.26,.09,M.shirt); torso.position.set(0,1.22,-.68); torso.rotation.x=.1; torso.castShadow=true; driverBody.add(torso);
  put(driverBody,sph(.145,M.skin,14,11),0,1.68,-.64);
  const beard=new THREE.Mesh(new THREE.ConeGeometry(.11,.22,8),new THREE.MeshStandardMaterial({color:0x5a4632,roughness:1}));
  beard.position.set(0,1.56,-.53); beard.rotation.x=.4; driverBody.add(beard);
  const capTop=sph(.155,new THREE.MeshStandardMaterial({color:0xb02018,roughness:.7}),12,8); capTop.position.set(0,1.76,-.65); capTop.scale.y=.55; driverBody.add(capTop);
  put(driverBody,box(.2,.02,.14,new THREE.MeshStandardMaterial({color:0xb02018,roughness:.7})),0,1.73,-.47);
  put(driverBody,box(.24,.05,.03,M.blackPlastic),0,1.69,-.5); // shades
  for(const sx of[-1,1]){const arm=cyl(.05,.045,.55,M.shirt,8); arm.position.set(sx*.28,1.2,-.42); arm.rotation.set(1.0,0,sx*.4); arm.castShadow=true; driverBody.add(arm)}
}

// ---------- your hands: full of beer & cigar, steering with the palm heel ----------
function makeHand(side){ // side -1 left, +1 right; local +Z = fingers direction
  const g=new THREE.Group();
  const palm=rbox(.088,.038,.1,.016,M.skin); palm.castShadow=true; g.add(palm);
  const heel=sph(.042,M.skin,10,8); heel.position.set(0,-.012,-.04); heel.scale.set(1,.7,1.1); g.add(heel);
  for(let f=0;f<4;f++){
    const fx=-.033+f*.022, fl=[.052,.06,.058,.045][f];
    const j1=new THREE.Group(); j1.position.set(fx,0,.048); j1.rotation.x=1.3+f*.05; g.add(j1);
    const s1=new THREE.Mesh(new THREE.CapsuleGeometry(.0105,fl*.5,3,8),M.skin); s1.position.y=fl*.3; s1.castShadow=true; j1.add(s1);
    const j2=new THREE.Group(); j2.position.y=fl*.55; j2.rotation.x=1.5; j1.add(j2);
    const s2=new THREE.Mesh(new THREE.CapsuleGeometry(.0095,fl*.42,3,8),M.skin); s2.position.y=fl*.26; s2.castShadow=true; j2.add(s2);
    const nail=box(.009,.011,.003,new THREE.MeshStandardMaterial({color:0xd8bda6,roughness:.35}));
    nail.position.set(0,fl*.46,.008); j2.add(nail);
  }
  const thumb=new THREE.Group(); thumb.position.set(-side*.045,0,.015); thumb.rotation.set(.5,0,side*.9); g.add(thumb);
  const t1=new THREE.Mesh(new THREE.CapsuleGeometry(.0115,.03,3,8),M.skin); t1.position.y=.022; t1.castShadow=true; thumb.add(t1);
  const tj=new THREE.Group(); tj.position.y=.045; tj.rotation.x=.5; thumb.add(tj);
  const t2=new THREE.Mesh(new THREE.CapsuleGeometry(.0105,.024,3,8),M.skin); t2.position.y=.018; tj.add(t2);
  // sun-browned forearm diving back to a rolled plaid sleeve
  const fore=cyl(.032,.039,.3,M.skin,10); fore.position.set(side*.015,-.045,-.18); fore.rotation.x=Math.PI/2-.22; fore.castShadow=true; g.add(fore);
  const sleeve=cyl(.052,.058,.2,M.shirt,10); sleeve.position.set(side*.025,-.075,-.35); sleeve.rotation.x=Math.PI/2-.22; g.add(sleeve);
  // (arm hair removed: read as stitches in close-up)
  return g;
}
const leftHand=makeHand(-1), rightHand=makeHand(1);
const LHOME={p:new THREE.Vector3(.225,1.055,.21),r:new THREE.Euler(.32,-.38,-.18)}; // +X reads as screen-left from the seat
const RHOME={p:new THREE.Vector3(-.225,1.055,.21),r:new THREE.Euler(.32,.38,.18)};
leftHand.position.copy(LHOME.p); leftHand.rotation.copy(LHOME.r);
rightHand.position.copy(RHOME.p); rightHand.rotation.copy(RHOME.r);
mower.add(leftHand,rightHand);

// THE BEER: brown glass, live liquid, condensation sweat, rising bubbles
const beerGroup=new THREE.Group(); beerGroup.position.set(.018,.01,.045); beerGroup.rotation.set(-.28,.3,.08); beerGroup.scale.setScalar(1.22); leftHand.add(beerGroup);
let liquidMesh,liquidTop,foamGroup,bubblePts,bubbleData;
{
  const profile=[[.001,0],[.03,0],[.036,.012],[.036,.15],[.032,.185],[.015,.23],[.0125,.262],[.015,.272],[.015,.288],[.011,.29]].map(p=>new THREE.Vector2(p[0],p[1]));
  const glass=new THREE.Mesh(new THREE.LatheGeometry(profile,22),
    new THREE.MeshPhysicalMaterial({color:0x7a4512,roughness:.06,metalness:0,transparent:true,opacity:.58,envMapIntensity:1.6,clearcoat:1,clearcoatRoughness:.08,side:THREE.DoubleSide,depthWrite:false}));
  glass.castShadow=true; beerGroup.add(glass);
  const punt=new THREE.Mesh(new THREE.CircleGeometry(.028,16),new THREE.MeshStandardMaterial({color:0x3c1e06,roughness:.3}));
  punt.rotation.x=Math.PI/2; punt.position.y=.004; beerGroup.add(punt);
  // liquid: amber body + tilting surface so it visibly SLOSHES over bumps
  const liqProfile=[[.001,.004],[.028,.004],[.032,.014],[.032,1]].map(p=>new THREE.Vector2(p[0],p[1]));
  liquidMesh=new THREE.Mesh(new THREE.LatheGeometry(liqProfile,18),
    new THREE.MeshPhysicalMaterial({color:0xd9820e,roughness:.08,emissive:0x6b3400,emissiveIntensity:.25,transparent:true,opacity:.94,envMapIntensity:1.1}));
  beerGroup.add(liquidMesh);
  liquidTop=new THREE.Mesh(new THREE.CircleGeometry(.032,18),new THREE.MeshStandardMaterial({color:0xf5a83c,roughness:.15,emissive:0x8a4a00,emissiveIntensity:.35}));
  liquidTop.rotation.x=-Math.PI/2; beerGroup.add(liquidTop);
  foamGroup=new THREE.Group(); beerGroup.add(foamGroup);
  const foamM=new THREE.MeshStandardMaterial({color:0xfff6dd,roughness:.9});
  for(let i=0;i<9;i++){const f=sph(rr(.006,.012),foamM,7,5); f.position.set(rr(-.02,.02),rr(-.003,.006),rr(-.02,.02)); foamGroup.add(f)}
  const lip=sph(.011,foamM,7,5); lip.position.set(.014,.004,.006); lip.scale.set(.7,1.4,.7); foamGroup.add(lip);
  // label + torn gold foil
  const label=new THREE.Mesh(new THREE.CylinderGeometry(.0375,.0375,.088,18,1,true,-.4,3.9),new THREE.MeshStandardMaterial({map:beerLabel,roughness:.6,side:THREE.DoubleSide}));
  label.position.y=.088; label.rotation.y=2.2; beerGroup.add(label);
  const foil=new THREE.Mesh(new THREE.CylinderGeometry(.0145,.0165,.05,12,1,true),new THREE.MeshStandardMaterial({color:0xd8a83c,roughness:.28,metalness:1,side:THREE.DoubleSide}));
  foil.position.y=.245; beerGroup.add(foil);
  // fingers wrapped round the bottle (torus arcs) + thumb up the far side
  for(let i=0;i<4;i++){
    const fg=new THREE.Mesh(new THREE.TorusGeometry(.0385,.0105,8,14,3.5),M.skin);
    fg.rotateX(Math.PI/2); fg.rotateY(2.1+i*.14);
    fg.position.y=.036+i*.025; fg.castShadow=true; beerGroup.add(fg);
    const tipNail=sph(.006,new THREE.MeshStandardMaterial({color:0xd8bda6,roughness:.35}),6,5);
    tipNail.position.set(.036,.036+i*.025,-.016); tipNail.scale.set(1,.55,1); beerGroup.add(tipNail);
  }
  const bThumb=new THREE.Mesh(new THREE.CapsuleGeometry(.0105,.055,3,8),M.skin);
  bThumb.position.set(-.039,.085,.004); bThumb.rotation.z=.12; bThumb.castShadow=true; beerGroup.add(bThumb);
  const lipRing=new THREE.Mesh(new THREE.TorusGeometry(.013,.0025,8,16),new THREE.MeshPhysicalMaterial({color:0x8a5a20,roughness:.1,transparent:true,opacity:.7,envMapIntensity:1.5}));
  lipRing.rotation.x=Math.PI/2; lipRing.position.y=.288; beerGroup.add(lipRing);
  // condensation: ninety ice-cold sweat beads + a few runners
  const dropGeo=new THREE.SphereGeometry(1,7,5);
  const dropMat=new THREE.MeshPhysicalMaterial({color:0xeaf6ff,roughness:.03,metalness:.05,transparent:true,opacity:.75,envMapIntensity:2});
  const drops=new THREE.InstancedMesh(dropGeo,dropMat,95);
  for(let i=0;i<95;i++){
    const a=rnd()*6.28, y=rr(.02,.21), rad=y<.15?.037:(y<.19?.033:.02);
    _v.set(Math.cos(a)*rad,y,Math.sin(a)*rad); _q.identity();
    const s=rr(.0011,.0029); _s.set(s,s*(rnd()<.22?2.6:1.1),s);
    _m4.compose(_v,_q,_s); drops.setMatrixAt(i,_m4);
  }
  beerGroup.add(drops);
  // rising bubble columns inside the amber
  const bn=42, barr=new Float32Array(bn*3); bubbleData=[];
  for(let i=0;i<bn;i++){const a=rnd()*6.28,rd=rr(.004,.026); bubbleData.push({x:Math.cos(a)*rd,z:Math.sin(a)*rd,y:rnd(),sp:rr(.14,.4)})}
  const bg=new THREE.BufferGeometry(); bg.setAttribute('position',new THREE.BufferAttribute(barr,3));
  bubblePts=new THREE.Points(bg,new THREE.PointsMaterial({map:softTex,color:0xffe2a0,size:.0075,transparent:true,opacity:.85,depthWrite:false}));
  beerGroup.add(bubblePts);
}
function setBeerLevel(frac){ // 0..1 of a full bottle (full = just below the shoulder, so the surface shows)
  const h=.015+frac*.16;
  liquidMesh.scale.set(1,h,1); liquidMesh.position.y=.004;
  liquidTop.position.y=h+.004; foamGroup.position.y=h+.006;
  liquidTop.visible=foamGroup.visible=frac>.015;
}
setBeerLevel(1);
// THE CIGAR: veined wrapper, red-gold band, grey ash, live ember
const cigarGroup=new THREE.Group(); cigarGroup.position.set(-.025,.02,.05); cigarGroup.rotation.set(-2.0,.15,.18); cigarGroup.scale.setScalar(1.18); rightHand.add(cigarGroup);
let cigarBody,cigarAsh,cigarEmber,emberLight,emberTip,emberGlowSprite;
{
  const wrapTex=ctex(128,128,(x,w,h)=>{x.fillStyle='#7a4a20';x.fillRect(0,0,w,h);
    for(let i=0;i<40;i++){x.strokeStyle=`rgba(${50+rnd()*40|0},${30+rnd()*22|0},10,.55)`;x.lineWidth=rr(.6,1.6);x.beginPath();x.moveTo(rnd()*w,0);x.bezierCurveTo(rnd()*w,h*.3,rnd()*w,h*.7,rnd()*w,h);x.stroke()}
    speckle(x,w,h,500,['#8a5a2c','#5f3a16'],1,2)},[2,1]);
  cigarBody=new THREE.Mesh(new THREE.CylinderGeometry(.0105,.0115,1,12),new THREE.MeshStandardMaterial({map:wrapTex,roughness:.82}));
  cigarBody.geometry.translate(0,.5,0); cigarBody.rotation.x=Math.PI/2; cigarBody.castShadow=true; cigarGroup.add(cigarBody);
  const band=new THREE.Mesh(new THREE.CylinderGeometry(.0122,.0122,.02,12),new THREE.MeshStandardMaterial({color:0xa01e20,roughness:.4,metalness:.35,emissive:0x30060a}));
  band.rotation.x=Math.PI/2; band.position.z=.032; cigarGroup.add(band);
  const bandGold=new THREE.Mesh(new THREE.CylinderGeometry(.0124,.0124,.004,12),M.brass);
  bandGold.rotation.x=Math.PI/2; bandGold.position.z=.032; cigarGroup.add(bandGold);
  cigarAsh=new THREE.Mesh(new THREE.CylinderGeometry(.0102,.0108,1,10),new THREE.MeshStandardMaterial({color:0xb9b4a8,roughness:1}));
  cigarAsh.geometry.translate(0,.5,0); cigarAsh.rotation.x=Math.PI/2; cigarGroup.add(cigarAsh);
  // index + middle finger pinching the stick, V-style
  for(const [fy,rz2] of [[.0145,.12],[-.0145,-.1]]){
    const pf=new THREE.Mesh(new THREE.CapsuleGeometry(.0095,.06,3,8),M.skin);
    pf.rotation.x=Math.PI/2; pf.rotation.y=rz2; pf.position.set(0,fy,.012); pf.castShadow=true; cigarGroup.add(pf);
  }
  cigarEmber=new THREE.Mesh(new THREE.CircleGeometry(.0102,12),new THREE.MeshStandardMaterial({color:0xff5a08,emissive:0xff4400,emissiveIntensity:2.2}));
  cigarGroup.add(cigarEmber);
  emberLight=new THREE.PointLight(0xff6a22,.55,.65,1.8); cigarGroup.add(emberLight);
  emberTip=new THREE.Object3D(); cigarGroup.add(emberTip);
  emberGlowSprite=new THREE.Sprite(new THREE.SpriteMaterial({map:softTex,color:0xff7a22,transparent:true,opacity:.6,blending:THREE.AdditiveBlending,depthWrite:false}));
  emberGlowSprite.scale.setScalar(.05); emberTip.add(emberGlowSprite);
}
function setCigar(frac){ // 1 = fresh stick, 0 = sad stub
  const len=.055+frac*.095, ashLen=clamp((1-frac)*.03,.004,.028);
  cigarBody.scale.set(1,len,1);
  cigarAsh.scale.set(1,ashLen,1); cigarAsh.position.z=len;
  cigarEmber.position.z=len+ashLen+.001;
  emberLight.position.z=len+ashLen+.02; emberTip.position.z=len+ashLen;
}
setCigar(1);
const _wv=new THREE.Vector3();
function worldOf(obj){return obj.getWorldPosition(_wv)}

// ---------- audio: a whole synth in your pocket (engine, gulps, birds) ----------
const AU={ok:false};
function initAudio(){
  if(AU.ok) return;
  try{
    const ctx=new (window.AudioContext||window.webkitAudioContext)(); AU.ctx=ctx;
    AU.master=ctx.createGain(); AU.master.gain.value=.8; AU.master.connect(ctx.destination);
    const nb=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate), d=nb.getChannelData(0);
    for(let i=0;i<d.length;i++) d[i]=Math.random()*2-1;
    AU.noiseBuf=nb;
    const mkNoise=()=>{const s=ctx.createBufferSource();s.buffer=nb;s.loop=true;s.start();return s};
    // engine: two detuned oscillators through a growly lowpass
    AU.engGain=ctx.createGain(); AU.engGain.gain.value=0;
    const lp=ctx.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=420; lp.Q.value=2;
    AU.osc1=ctx.createOscillator(); AU.osc1.type='sawtooth'; AU.osc1.frequency.value=52;
    AU.osc2=ctx.createOscillator(); AU.osc2.type='square'; AU.osc2.frequency.value=26;
    const g2=ctx.createGain(); g2.gain.value=.6;
    AU.osc1.connect(lp); AU.osc2.connect(g2); g2.connect(lp); lp.connect(AU.engGain); AU.engGain.connect(AU.master);
    AU.osc1.start(); AU.osc2.start(); AU.engLP=lp;
    // blade whir + grass rustle share a noise/bandpass lane
    AU.bladeGain=ctx.createGain(); AU.bladeGain.gain.value=0;
    const bp=ctx.createBiquadFilter(); bp.type='bandpass'; bp.frequency.value=1100; bp.Q.value=.7;
    mkNoise().connect(bp); bp.connect(AU.bladeGain); AU.bladeGain.connect(AU.master); AU.bladeBP=bp;
    // gentle evening breeze bed
    AU.windGain=ctx.createGain(); AU.windGain.gain.value=.015;
    const wlp=ctx.createBiquadFilter(); wlp.type='lowpass'; wlp.frequency.value=320;
    mkNoise().connect(wlp); wlp.connect(AU.windGain); AU.windGain.connect(AU.master);
    AU.ok=true;
  }catch(e){AU.ok=false}
}
function tone(freq0,freq1,dur,type='sine',vol=.2,delay=0){
  if(!AU.ok) return; const ctx=AU.ctx,t=ctx.currentTime+delay;
  const o=ctx.createOscillator(),g=ctx.createGain(); o.type=type;
  o.frequency.setValueAtTime(freq0,t); o.frequency.exponentialRampToValueAtTime(Math.max(1,freq1),t+dur);
  g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(vol,t+.015); g.gain.exponentialRampToValueAtTime(.001,t+dur);
  o.connect(g); g.connect(AU.master); o.start(t); o.stop(t+dur+.05);
}
function noiseBurst(dur,freq,type='bandpass',vol=.25,delay=0,freq1=0){
  if(!AU.ok) return; const ctx=AU.ctx,t=ctx.currentTime+delay;
  const s=ctx.createBufferSource(); s.buffer=AU.noiseBuf; s.loop=true;
  const f=ctx.createBiquadFilter(); f.type=type; f.frequency.setValueAtTime(freq,t);
  if(freq1) f.frequency.exponentialRampToValueAtTime(freq1,t+dur);
  const g=ctx.createGain(); g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(vol,t+dur*.25); g.gain.exponentialRampToValueAtTime(.001,t+dur);
  s.connect(f); f.connect(g); g.connect(AU.master); s.start(t); s.stop(t+dur+.05);
}
const sfx={
  starter(){for(let i=0;i<4;i++) tone(70,45,.16,'sawtooth',.3,i*.19); noiseBurst(.7,300,'lowpass',.2,.1)},
  gulp(){for(let i=0;i<3;i++){tone(340,90,.16,'sine',.28,i*.24); noiseBurst(.1,700,'bandpass',.1,i*.24)} tone(180,320,.25,'sine',.12,.8)},
  crack(){noiseBurst(.35,3200,'highpass',.3,0,1400); tone(900,300,.07,'square',.12)},
  draw(){noiseBurst(.8,900,'bandpass',.16,0,500)},
  exhale(){noiseBurst(1.3,500,'lowpass',.22,0,240)},
  thud(v=1){tone(95,38,.2,'sine',.4*Math.min(1,v)); noiseBurst(.15,250,'lowpass',.3*Math.min(1,v))},
  chirp(){const f=2200+Math.random()*1200; for(let i=0;i<3;i++) tone(f,f*1.3,.07,'sine',.035,i*.11)},
  milestone(){[523,659,784].forEach((f,i)=>tone(f,f,.35,'triangle',.16,i*.12))},
  win(){[523,659,784,1046,784,1046,1318].forEach((f,i)=>tone(f,f,.5,'triangle',.18,i*.16))},
  pop(){tone(500,180,.08,'sine',.2)},
};
function updateAudio(rpm,load,cutting,speedAbs){
  if(!AU.ok) return; const t=AU.ctx.currentTime;
  const wob=Math.sin(t*31)*3*load;
  AU.osc1.frequency.setTargetAtTime(46+rpm*58+wob,t,.06);
  AU.osc2.frequency.setTargetAtTime(23+rpm*29+wob*.5,t,.06);
  AU.engLP.frequency.setTargetAtTime(300+rpm*650,t,.1);
  AU.engGain.gain.setTargetAtTime(.10+rpm*.16,t,.1);
  AU.bladeBP.frequency.setTargetAtTime(900+rpm*900,t,.12);
  AU.bladeGain.gain.setTargetAtTime(rpm>0.05?(.028+cutting*.30+Math.min(.05,speedAbs*.006)):0,t,.09);
  if(Math.random()<.0016) sfx.chirp();
}

// ---------- game state, input, the sacred Q and E ----------
const S={started:false,x:8.5,z:24,yaw:Math.PI,speed:0,steer:0,rpm:0,load:0,
  beer:1,cigar:1,beersDown:0,puffs:0,time:0,won:false,chase:false,
  lookYaw:0,lookPitch:-.08,drinkT:-1,smokeT:-1,drewPuff:false,exhaled:false,gulped:false,
  emberGlow:.6,sloshX:0,sloshZ:0,prevSpeed:0,buzz:0,bouncePh:0,bounce:0,shake:0,
  mileIdx:0,paintDist:0,smokeAcc:0,exhaustAcc:0,hudAcc:0,mapAcc:0,impactCd:0,cutSmooth:0};
const START={x:S.x,z:S.z,yaw:S.yaw};
const keys=new Set();
const MILESTONES=[
  [10,"10% — A PATH APPEARS","Somewhere under there is a garden party from 1962."],
  [25,"25% — THE DUKE STIRS","A quarter tamed. The statues look less ashamed."],
  [50,"50% — HALF A MASTERPIECE","Stripes! Actual stripes! Wimbledon is nervous."],
  [75,"75% — THE JUNGLE RETREATS","The heron by the pond just stood up straighter."],
  [90,"90% — ESTATE SAVED","Look at it. LOOK AT IT. Someone fetch a portrait painter."],
];
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.remove('pop');void t.offsetWidth;t.classList.add('pop')}
function centre(msg){const t=$('centre');t.textContent=msg;t.classList.remove('pop');void t.offsetWidth;t.classList.add('pop')}
addEventListener('keydown',e=>{
  if(['KeyW','KeyA','KeyS','KeyD','Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if(e.repeat) return; keys.add(e.code);
  if(!S.started&&(e.code==='Enter'||e.code==='Space')){startGame();return}
  if(!S.started) return;
  if(e.code==='KeyQ') doDrink();
  if(e.code==='KeyE') doSmoke();
  if(e.code==='KeyC'){S.chase=!S.chase;driverBody.visible=S.chase;toast(S.chase?'CHASE CAM — look at that Titan go':'BACK IN THE SADDLE')}
});
addEventListener('keyup',e=>keys.delete(e.code));
addEventListener('blur',()=>keys.clear());
// drag to look around (admire your work / the lit window / your beer)
let dragId=null,lastPX=0,lastPY=0;
const cv=$('c');
cv.addEventListener('pointerdown',e=>{dragId=e.pointerId;lastPX=e.clientX;lastPY=e.clientY;cv.setPointerCapture(e.pointerId)});
cv.addEventListener('pointermove',e=>{
  if(e.pointerId!==dragId) return;
  S.lookYaw=clamp(S.lookYaw-(e.clientX-lastPX)*.0048,-1.35,1.35);
  S.lookPitch=clamp(S.lookPitch-(e.clientY-lastPY)*.0042,-.6,.38);
  lastPX=e.clientX;lastPY=e.clientY;
});
cv.addEventListener('pointerup',()=>dragId=null);
cv.addEventListener('dblclick',()=>{S.lookYaw=0;S.lookPitch=-.08});
// touch buttons
for(const b of document.querySelectorAll('#touch button')){
  const code=b.dataset.k;
  const on=e=>{e.preventDefault();b.classList.add('on');keys.add(code);
    if(code==='KeyQ')doDrink(); if(code==='KeyE')doSmoke();};
  const off=e=>{e.preventDefault();b.classList.remove('on');keys.delete(code)};
  b.addEventListener('pointerdown',on); b.addEventListener('pointerup',off); b.addEventListener('pointerleave',off); b.addEventListener('pointercancel',off);
}
const GLUGS=['GLUG GLUG GLUG… ahhh.','ICE COLD. POETRY.','That one was for the east lawn.','Hydration is a mowing technique.','The Duke nods approvingly from a portrait.'];
function doDrink(){
  if(!S.started||S.drinkT>=0) return;
  if(S.beer<=.03){
    S.beer=1; setBeerLevel(1); sfx.crack();
    toast('CRACKED A FRESH ONE FROM THE COOLER'); return;
  }
  S.drinkT=0; S.gulped=false;
}
function doSmoke(){
  if(!S.started||S.smokeT>=0) return;
  if(S.cigar<=.01){toast('THE CIGAR IS DONE. A MOMENT OF SILENCE.');sfx.pop();return}
  S.smokeT=0; S.drewPuff=false; S.exhaled=false; S.puffs++;
}
const mouthCleanups=[];
function animHands(dt,t){
  // drink envelope: raise .0-.3, tilt & gulp .3-1.15, return by 1.7
  let lEnv=0,lTilt=0;
  if(S.drinkT>=0){
    S.drinkT+=dt; const k=S.drinkT;
    lEnv=k<.32?smooth(k/.32):k>1.25?1-smooth(clamp((k-1.25)/.45,0,1)):1;
    lTilt=k<.35?0:k<.55?smooth((k-.35)/.2):k>1.05?1-smooth(clamp((k-1.05)/.25,0,1)):1;
    if(k>=.35&&!S.gulped){S.gulped=true;sfx.gulp()}
    if(k>.4&&k<1.05){
      const wasBeer=S.beer;
      S.beer=Math.max(0,S.beer-dt*.34); setBeerLevel(S.beer);
      if(wasBeer>0&&S.beer===0) S.beersDown++;
    }
    if(k>=1.7){S.drinkT=-1;S.buzz=clamp(S.buzz+.09,0,.8);
      toast(S.beer<=0.01?'BOTTLE DOWN. Q FOR ANOTHER COLD ONE':GLUGS[(Math.random()*GLUGS.length)|0])}
  }
  const mouthL=_v.set(.11,1.29,-.13);
  leftHand.position.lerpVectors(LHOME.p,mouthL,lEnv);
  leftHand.rotation.set(lerp(LHOME.r.x,.05,lEnv),lerp(LHOME.r.y,0,lEnv),lerp(LHOME.r.z,-.05,lEnv));
  beerGroup.rotation.set(-.28-lTilt*1.65,.3,.08-lTilt*.1); // bottoms up: mouth swings back to your face
  // smoke envelope: raise, draw (ember flares), exhale cloud, return
  let rEnv=0;
  if(S.smokeT>=0){
    S.smokeT+=dt; const k=S.smokeT;
    rEnv=k<.35?smooth(k/.35):k>1.45?1-smooth(clamp((k-1.45)/.55,0,1)):1;
    if(k>=.35&&!S.drewPuff){S.drewPuff=true;sfx.draw()}
    if(k>.4&&k<1.1){S.cigar=Math.max(0,S.cigar-dt*.085);setCigar(S.cigar);S.emberGlow=lerp(S.emberGlow,2.6,dt*7)}
    if(k>=1.12&&!S.exhaled){
      S.exhaled=true; sfx.exhale(); S.buzz=clamp(S.buzz+.03,0,.8);
      const f={x:Math.sin(S.yaw),z:Math.cos(S.yaw)};
      const mx=S.x+f.x*.15,mz=S.z+f.z*.15;
      for(let i=0;i<12;i++)
        spawnSmoke(mx+rr(-.06,.06),1.42+rr(-.05,.08),mz+rr(-.06,.06),
          f.x*rr(.5,1.1)+rr(-.12,.12),rr(.02,.22),f.z*rr(.5,1.1)+rr(-.12,.12),
          rr(.12,.24),rr(1.4,2.4),rr(.15,.27),0xe4e4e4,2.2);
      toast(['SMOOTH. NOTES OF CEDAR AND VICTORY.','A smoke ring drifts over your domain.','The west wing smells expensive now.'][(Math.random()*3)|0]);
    }
    if(k>=2.05) S.smokeT=-1;
  }
  S.emberGlow=lerp(S.emberGlow,.6+Math.sin(t*2.3)*.15,dt*2.5);
  const mouthR=new THREE.Vector3(-.11,1.29,-.13);
  rightHand.position.lerpVectors(RHOME.p,mouthR,rEnv);
  rightHand.rotation.set(lerp(RHOME.r.x,.05,rEnv),lerp(RHOME.r.y,.05,rEnv),lerp(RHOME.r.z,.1,rEnv));
  cigarGroup.rotation.set(lerp(-2.0,-.65,rEnv),.15,.18); // home: ember face toward you; puffing: tip forward
  // engine tremor through your arms + palm pressure on the rim
  const vib=REDUCED?0:(.0016+S.rpm*.0028+S.load*.002);
  leftHand.position.y+=Math.sin(t*47)*vib; rightHand.position.y+=Math.cos(t*43)*vib;
  leftHand.position.x+=Math.sin(t*39)*vib*.7; rightHand.position.x+=Math.sin(t*41+2)*vib*.7;
  cigarEmber.material.emissiveIntensity=S.emberGlow*1.6;
  emberLight.intensity=.25+S.emberGlow*.35;
  if(emberGlowSprite){emberGlowSprite.scale.setScalar(.038+S.emberGlow*.022); emberGlowSprite.material.opacity=clamp(.3+S.emberGlow*.22,0,.85); emberGlowSprite.visible=S.cigar>0}
  // the sacred slosh: liquid lags accel & steering, jostles over bumps
  const accel=dt>0?(S.speed-S.prevSpeed)/dt:0; S.prevSpeed=S.speed;
  const tX=clamp(-accel*.045,-.3,.3)+Math.sin(t*6.3)*Math.abs(S.bounce)*2.2;
  const tZ=clamp(S.steer*S.speed*.06,-.32,.32)+Math.cos(t*5.1)*Math.abs(S.bounce)*1.8+lTilt*.2;
  S.sloshX=lerp(S.sloshX,tX,1-Math.pow(.0015,dt));
  S.sloshZ=lerp(S.sloshZ,tZ,1-Math.pow(.0015,dt));
  liquidTop.rotation.set(-Math.PI/2+S.sloshX,0,S.sloshZ);
  liquidMesh.rotation.set(S.sloshX*.45,0,S.sloshZ*.45);
  foamGroup.rotation.set(S.sloshX*.7,0,S.sloshZ*.7);
  // bubbles race up, faster right after a gulp
  const bp=bubblePts.geometry.attributes.position, fizz=S.drinkT>=0?2.2:1;
  const topY=.015+S.beer*.16;
  for(let i=0;i<bubbleData.length;i++){const b=bubbleData[i]; b.y+=b.sp*fizz*dt; if(b.y>1)b.y=0;
    bp.setXYZ(i,b.x,.012+b.y*topY,b.z)}
  bp.needsUpdate=true;
  bubblePts.visible=S.beer>.02;
  // cigar ribbon smoke + a slow idle burn
  if(S.started&&S.cigar>0){
    S.cigar=Math.max(0,S.cigar-dt*.0011); if((t*10|0)!==((t+dt)*10|0)) setCigar(S.cigar);
    S.smokeAcc+=dt;
    if(S.smokeAcc>.1){S.smokeAcc=0; const p=worldOf(emberTip).clone();
      spawnSmoke(p.x,p.y,p.z,rr(-.03,.05),rr(.22,.34),rr(-.03,.05),.045,rr(1.1,1.8),.32,0xd8dee6,1.1)}
  }
}

// ---------- driving, collisions, camera, HUD ----------
function collide(){
  const R=.78;
  for(const c of COL_C){
    const dx=S.x-c.x,dz=S.z-c.z,d=Math.hypot(dx,dz),min=c.r+R;
    if(d<min&&d>1e-4){
      const push=(min-d); S.x+=dx/d*push; S.z+=dz/d*push;
      impact(Math.abs(S.speed));
    }
  }
  for(const b of COL_B){
    if(S.x>b.x0-R&&S.x<b.x1+R&&S.z>b.z0-R&&S.z<b.z1+R){
      const dl=S.x-(b.x0-R),dr=(b.x1+R)-S.x,dn=S.z-(b.z0-R),df=(b.z1+R)-S.z;
      const m=Math.min(dl,dr,dn,df);
      if(m===dl)S.x=b.x0-R; else if(m===dr)S.x=b.x1+R; else if(m===dn)S.z=b.z0-R; else S.z=b.z1+R;
      impact(Math.abs(S.speed));
    }
  }
  S.x=clamp(S.x,-38.8,38.8); S.z=clamp(S.z,-32.8,33.2);
}
function impact(sp){
  if(sp<1.1||S.impactCd>0){if(sp>=1.1)S.speed*=.4;return}
  S.impactCd=.45; S.shake=Math.min(1,sp*.22); S.speed*=.32; sfx.thud(sp*.3);
  if(sp>2.4&&S.beer>.05){S.beer=Math.max(0,S.beer-.04);setBeerLevel(S.beer);toast('CLONK! You spilled a little. A tragedy in miniature.')}
  else if(sp>1.6) toast('CLONK. The Titan forgives. The statue does not.');
}
const mapCtx=$('map').getContext('2d');
function drawMap(){
  const w=176,h=144;
  mapCtx.drawImage(groundCanvas,0,0,w,h);
  mapCtx.fillStyle='#c9bb96'; mapCtx.fillRect(((-26-LAWN.x0)/80)*w,((-33-LAWN.z0)/68)*h,(52/80)*w,(15/68)*h);
  mapCtx.fillStyle='#a79a80'; mapCtx.fillRect(((0-LAWN.x0)/80)*w-4,((-16-LAWN.z0)/68)*h,8,h);
  mapCtx.beginPath(); mapCtx.arc(((0-LAWN.x0)/80)*w,((-6-LAWN.z0)/68)*h,7,0,6.3); mapCtx.fillStyle='#7d94b8'; mapCtx.fill();
  mapCtx.beginPath(); mapCtx.arc(((-29-LAWN.x0)/80)*w,((22-LAWN.z0)/68)*h,10,0,6.3); mapCtx.fillStyle='#35504a'; mapCtx.fill();
  const mx=((S.x-LAWN.x0)/80)*w, mz=((S.z-LAWN.z0)/68)*h;
  mapCtx.save(); mapCtx.translate(mx,mz); mapCtx.rotate(Math.PI-S.yaw);
  mapCtx.fillStyle='#111'; mapCtx.beginPath(); mapCtx.moveTo(0,-7); mapCtx.lineTo(4,5); mapCtx.lineTo(-4,5); mapCtx.closePath(); mapCtx.fill();
  mapCtx.fillStyle='#ffdf5a'; mapCtx.beginPath(); mapCtx.arc(0,0,2.6,0,6.3); mapCtx.fill(); mapCtx.restore();
  mapCtx.fillStyle='#ffe9a8'; mapCtx.font='800 9px Archivo,Arial'; mapCtx.fillText('N — THE MANOR',6,11);
}
function updateHUD(){
  const pct=cutCount/GRASS_N*100;
  $('pct').textContent=pct.toFixed(1)+'%';
  $('mowbar').style.width=pct+'%';
  $('beerpct').textContent=Math.round(S.beer*100)+'%'; $('beerbar').style.width=(S.beer*100)+'%';
  $('cigarpct').textContent=Math.round(S.cigar*100)+'%'; $('cigarbar').style.width=(S.cigar*100)+'%';
  $('speed').textContent=(Math.abs(S.speed)*2.237).toFixed(0)+' mph';
  const mm=String((S.time/60)|0).padStart(2,'0'), ss=String((S.time%60)|0).padStart(2,'0');
  $('clock').textContent=mm+':'+ss;
  $('beers').textContent='empties ×'+S.beersDown;
  $('buzz').style.opacity=S.buzz*.8;
  if(S.mileIdx<MILESTONES.length&&pct>=MILESTONES[S.mileIdx][0]){
    const [,big,sub]=MILESTONES[S.mileIdx++]; centre(big); $('milestone').textContent=sub; sfx.milestone();
    if(pct>=90&&!S.won){S.won=true; sfx.win();
      $('winstats').textContent=`${pct.toFixed(1)}% mowed in ${mm}:${ss} · ${S.beersDown+(S.beer<1?1:0)} beer(s) deep · ${S.puffs} puffs of pure class`;
      setTimeout(()=>$('win').classList.remove('hidden'),900);}
  }
}
function resetEstate(){
  GRASS_CUT.fill(0); FLOWER_CUT.fill(0); falling.length=0; cutCount=0;
  for(let i=0;i<GRASS_N;i++){grassMatrix(i,1);grassColor(i,false)}
  grassMesh.instanceMatrix.needsUpdate=true; grassMesh.instanceColor.needsUpdate=true;
  for(let i=0;i<flowerMesh.count;i++){
    _e.set(0,FLOWER_ORIG[i*3+2],0);_q.setFromEuler(_e);
    _v.set(FLOWER_POS[i*2],FLOWER_ORIG[i*3],FLOWER_POS[i*2+1]);_s.setScalar(FLOWER_ORIG[i*3+1]);
    _m4.compose(_v,_q,_s); flowerMesh.setMatrixAt(i,_m4);
  }
  flowerMesh.instanceMatrix.needsUpdate=true;
  paintBaseGround(); groundTex.needsUpdate=true;
  Object.assign(S,{x:START.x,z:START.z,yaw:START.yaw,speed:0,steer:0,beer:1,cigar:1,beersDown:0,puffs:0,time:0,won:false,drinkT:-1,smokeT:-1,buzz:0,mileIdx:0,shake:0});
  setBeerLevel(1); setCigar(1);
  $('milestone').textContent='It grew back overnight. It always grows back. Glorious.';
  $('win').classList.add('hidden'); drawMap(); updateHUD();
  toast('THE JUNGLE RETURNS. SO DO YOU.');
}
function startGame(){
  if(S.started) return;
  initAudio(); if(AU.ctx&&AU.ctx.state==='suspended') AU.ctx.resume();
  sfx.starter();
  S.started=true; S.lookYaw=0; S.lookPitch=-.08;
  $('title').classList.add('hidden'); $('hud').classList.remove('hidden'); $('map').classList.remove('hidden');
  $('pauseBtn').classList.remove('hidden'); $('touch').classList.add('on');
  drawMap(); updateHUD();
  setTimeout(()=>toast('W — unleash the Titan. Mind the cherub.'),700);
}
$('start').addEventListener('click',startGame);
$('title').addEventListener('click',startGame);
$('keep').addEventListener('click',()=>{$('win').classList.add('hidden');sfx.pop()});
$('again').addEventListener('click',resetEstate);
$('pauseBtn').addEventListener('click',resetEstate);

// ---------- main loop ----------
const clockT=new THREE.Clock();
const chasePos=new THREE.Vector3(S.x-4,3,S.z+6);
function frame(){
  requestAnimationFrame(frame);
  const dt=Math.min(clockT.getDelta(),.05), t=clockT.elapsedTime;
  grassTime.value=t;
  S.impactCd=Math.max(0,S.impactCd-dt); S.shake=Math.max(0,S.shake-dt*2.2);
  // --- driving physics (palm steering included at no extra charge) ---
  let throttle=0, steerIn=0;
  if(S.started){
    S.time+=dt;
    if(keys.has('KeyW')||keys.has('ArrowUp')) throttle+=1;
    if(keys.has('KeyS')||keys.has('ArrowDown')) throttle-=1;
    if(keys.has('KeyA')||keys.has('ArrowLeft')) steerIn+=1;
    if(keys.has('KeyD')||keys.has('ArrowRight')) steerIn-=1;
    if(S.drinkT>=0) steerIn=steerIn*.55+Math.sin(t*2.6)*.13;       // one palm, full send, slight wander
    else if(S.smokeT>=0) steerIn*=.75;
    steerIn+=Math.sin(t*1.7)*S.buzz*.05;                              // the golden buzz drift
  }
  S.steer=lerp(S.steer,steerIn,1-Math.pow(.0005,dt));
  S.cutSmooth=lerp(S.cutSmooth,clamp(cutThisFrame/14,0,1),dt*5);
  S.load=clamp(S.cutSmooth*.8+clamp(tallNear/60,0,1)*.35,0,1);
  const maxF=5.4*(1-S.load*.42);
  let desired=throttle>0?maxF:throttle<0?-2.0:0;
  if(keys.has('Space')) desired=0;
  const rate=(throttle!==0&&Math.sign(desired)===Math.sign(S.speed+.001))?1.35:3.2;
  S.speed=lerp(S.speed,desired,1-Math.exp(-rate*dt));
  if(Math.abs(S.speed)<.02&&throttle===0) S.speed=0;
  const turnAuthority=clamp(S.speed/2.4,-1,1);
  S.yaw+=S.steer*1.18*turnAuthority*dt*(1-.25*Math.min(1,Math.abs(S.speed)/6));
  const fx=Math.sin(S.yaw),fz=Math.cos(S.yaw),rx=Math.cos(S.yaw),rz=-Math.sin(S.yaw);
  if(S.started){
    S.x+=fx*S.speed*dt; S.z+=fz*S.speed*dt;
    collide();
  }
  // --- cutting ---
  let cuttingNow=0;
  if(S.started&&Math.abs(S.speed)>.25){
    const deckX=S.x+fx*.3, deckZ=S.z+fz*.3;
    cutAt(deckX,deckZ,S.yaw,S.yaw-Math.PI/2,.8,1.3,.85);
    cutFlowers(deckX,deckZ);
    cuttingNow=cutThisFrame;
    S.paintDist+=Math.abs(S.speed)*dt;
    if(cutThisFrame>0){
      const chuteX=S.x+rx*.95+fx*.3, chuteZ=S.z+rz*.95+fz*.3;
      spawnClippings(chuteX,chuteZ,3);
      if(S.paintDist>.12){paintMow(deckX,deckZ,S.yaw);S.paintDist=0}
    } else if(S.paintDist>.35){paintMow(deckX,deckZ,S.yaw);S.paintDist=0}
  } else {cutThisFrame=0;tallNear=0}
  // --- mower body language ---
  const rpmTarget=!S.started?0:clamp(.34+Math.abs(throttle)*.5+Math.abs(S.speed)*.045-S.load*.16,0,1);
  S.rpm=lerp(S.rpm,rpmTarget,1-Math.exp(-2.6*dt));
  S.bouncePh+=Math.abs(S.speed)*dt*2.4;
  const bAmp=REDUCED?0:clamp(Math.abs(S.speed)/5,0,1)*(.012+S.load*.014);
  S.bounce=Math.sin(S.bouncePh*7.3)*bAmp+Math.sin(S.bouncePh*12.7)*bAmp*.5;
  mower.position.set(S.x,S.bounce,S.z);
  mower.rotation.set(Math.sin(S.bouncePh*6.1)*bAmp*.7,S.yaw,Math.sin(S.bouncePh*5.2)*bAmp*.8-S.steer*Math.abs(S.speed)*.006);
  steeringWheel.rotation.z=-S.steer*1.9;
  for(const p of wheelPivots) p.rotation.y=S.steer*.42;
  const radii=[.26,.26,.39,.39];
  wheelSpin.forEach((w,i)=>w.rotation.x+=S.speed*dt/radii[i]);
  bladeDisc.rotation.z+=S.rpm*46*dt;
  bladeDisc.material.opacity=S.rpm>.1?.32:0;
  throttleLever.rotation.x=-.25-S.rpm*.55;
  if(rpmNeedle) rpmNeedle.children[0].rotation.z=2.05-S.rpm*4.1;
  if(mphNeedle) mphNeedle.children[0].rotation.z=2.05-clamp(Math.abs(S.speed)/5.6,0,1)*4.1;
  // exhaust puffs, chuggier under load
  if(S.started){
    S.exhaustAcc+=dt*(2+S.rpm*7+S.load*4);
    if(S.exhaustAcc>1){S.exhaustAcc=0; const p=worldOf(exhaustTip).clone();
      spawnSmoke(p.x,p.y+.03,p.z,rr(-.08,.08),rr(.7,1.15),rr(-.08,.08),rr(.07,.12),rr(.7,1.2),.3,0x8f9296,1.5)}
  }
  animHands(S.started?dt:Math.min(dt,.016),t);
  updateFalling(dt); updateClips(dt); updateSmoke(dt,t); updateWildlife(dt,t,S.x,S.z);
  updateAudio(S.rpm,S.load,clamp(cuttingNow/12,0,1),Math.abs(S.speed));
  // --- camera ---
  const shakeAmp=REDUCED?0:(.004+S.rpm*.006+S.load*.006+S.shake*.05);
  const shX=(Math.sin(t*43.7)+Math.sin(t*31.3)*.6)*shakeAmp, shY=(Math.cos(t*47.9)+Math.sin(t*37.1)*.6)*shakeAmp;
  if(S.chase){
    const want=new THREE.Vector3(S.x-fx*5.4,2.5,S.z-fz*5.4);
    chasePos.lerp(want,1-Math.exp(-4.5*dt));
    camera.position.copy(chasePos); camera.position.y+=shY*2;
    camera.lookAt(S.x+fx*2.2,1.0,S.z+fz*2.2);
  }else{
    const camY=1.44+S.bounce*.55+shY;
    camera.position.set(S.x-fx*.56+rx*shX,camY,S.z-fz*.56+rz*shX);
    if(!S.started){ // title-screen idle: in the seat, taking it all in
      S.lookYaw=Math.sin(t*.14)*.22; S.lookPitch=-.08+Math.sin(t*.09)*.02;
    }
    const ly=S.yaw+S.lookYaw, cp=Math.cos(S.lookPitch);
    camera.lookAt(camera.position.x+Math.sin(ly)*cp,camera.position.y+Math.sin(S.lookPitch),camera.position.z+Math.cos(ly)*cp);
    camera.rotation.z+=(-S.steer*Math.abs(S.speed)*.004)+(REDUCED?0:Math.sin(t*.9)*S.buzz*.012);
  }
  // --- HUD cadence ---
  if(S.started){
    S.hudAcc+=dt; if(S.hudAcc>.12){S.hudAcc=0;updateHUD()}
    S.mapAcc+=dt; if(S.mapAcc>.3){S.mapAcc=0;drawMap()}
  }
  renderer.render(scene,camera);
}
mower.position.set(S.x,0,S.z); mower.rotation.y=S.yaw;
console.log('DUKE\'S RUIN ready — grass tufts:',GRASS_N,'flowers:',flowerMesh.count);
frame();










